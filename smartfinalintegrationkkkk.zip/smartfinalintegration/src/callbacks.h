#include <gtk/gtk.h>


void
on_CG_auth_insc_btn_clicked            (GtkWidget      *objet,
                                        gpointer         user_data);
void
on_CG_auth_connecter_btn_clicked       (GtkWidget      *objet,
                                       gpointer         user_data);

void
on_CG_quitter_btn_clicked              (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_CG_treeview_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_CG_aff_retour_btn_clicked           (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_CG_aff_modif_btn_clicked             (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_CG_aff_supp_btn_clicked             (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_CG_aff_rech_btn_clicked             (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_CG_aff_add_btn_clicked              (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_CG_add_retour_btn_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_CG_add_add_btn_clicked              (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_CG_modif_annuler_btn_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_CG_modif_modif_btn_clicked          (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_CG_modif_chercher_btn_clicked       (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_CG_aff_users_btn_clicked            (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_CG_inscrit_admin_incrit_btn_clicked (GtkButton       *button,
                                        gpointer         user_data);

void
on_CG_inscrit_admin_retour_btn_clicked (GtkButton       *button,
                                        gpointer         user_data);

void
on_CG_confirmer_check_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_CG_add_homme_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_CG_add_femme_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_CG_accualiser_clicked               (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_CG_modif_homme_activate             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_CG_modif_femme_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_CG_treeetage_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);
void 
on_CG_etage_row_activated              (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);
void
on_CG_refresh_etage_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

