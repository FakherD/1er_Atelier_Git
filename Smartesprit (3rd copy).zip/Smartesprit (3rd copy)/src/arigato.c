#include "arigato.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
enum
{ 
 EcaptID,
    EcaptMarque,
     EcaptType,
      EJourCap,
       EMoisCap,
        EAnneeCap,
        EcaptValMin,
        EcaptValMax,
        EcaptZone,
ID,
NOM,
PRENOM,
CIN,
SEXE,
DATE_NAISSANCE,
GSM,
NIVEAUX,
USERNAME,
PASSWORD,
ETAGE,
CHAMBRE,
TYPE,
/*NIVEAU,*/
EID, 
EDATE,
ENOM,
ETYPE,
EENTREE,
ESUITE,
EDESSERT,
 EIDDD,
 ENOMMM,
 ECATEGGG,
 EPRIXXX,
 EMARQUE,
 EDATEF,
 EDATEE,
 EQUANT,
COLUMNS, 

};
int ajouter_capt(capteur C)
{
FILE *f=NULL;
f=fopen("cap.txt","a+") ;

if(f!=NULL)
{
fprintf(f,"%s %s %s %d %d %d %s %s %s \n" , C.captID , C.captMarque ,
C.captType ,C.JourCap ,C.MoisCap,C.AnneeCap,C.captValMin,C.captValMax,C.captZone );
fclose(f);
return 1;
}
else
return 0;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////

int exist_capteur(char *id)
{
FILE*f=NULL;
capteur C;
f=fopen("cap.txt","r");// ouverture du fichier capteur en  mode lecture 
   while(fscanf(f, "%s %s %s %d %d %d %s %s %s \n" ,C.captID , C.captMarque ,C.captType ,&C.JourCap,&C.MoisCap,&C.AnneeCap,C.captValMin,C.captValMax,C.captZone )!=EOF)
{
if(strcmp(C.captID,id)==0)
return 1;   //id existe deja 
}
fclose(f);
return 0;
}

//////////////////////////////////////

void afficher_capteur(GtkWidget  *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	char captID[20];
	char captMarque[20];
	char captType[20];
	int  JourCap;
	int MoisCap;
        int AnneeCap;
	char captValMin[20];
	char captValMax[20];
	char captZone[20];
	store=NULL;

	FILE *f;

	store=gtk_tree_view_get_model(liste);
	if(store==NULL)
	{
	renderer =gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("captID",renderer, "text",EcaptID,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column =gtk_tree_view_column_new_with_attributes("captMarque",renderer,"text",EcaptMarque,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" captType",renderer, "text", EcaptType,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" JourCap",renderer, "text", EJourCap,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("MoisCap",renderer, "text",EMoisCap,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("AnneeCap",renderer, "text",EAnneeCap,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" captValMin",renderer, "text",EcaptValMin,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("captValMax",renderer, "text",EcaptValMax,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("captZone",renderer, "text",EcaptZone,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	}
	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING,  G_TYPE_STRING,  G_TYPE_STRING,  G_TYPE_INT,  G_TYPE_INT, 		G_TYPE_INT, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
	f=fopen("cap.txt","r");
	if(f==NULL)
	{
		return;
	}
	else
	{
		f= fopen("cap.txt","a+");
	 	while(fscanf(f,"%s %s %s %d %d %d %s %s %s \n",captID,captMarque,captType,&JourCap,&MoisCap,&AnneeCap,captValMin,
	captValMax,captZone )!=EOF)	          						  
		{
			gtk_list_store_append(store, &iter);
			gtk_list_store_set(store,&iter, EcaptID,captID,EcaptMarque,captMarque,EcaptType,captType,EJourCap,JourCap,
			EMoisCap,MoisCap,EAnneeCap,AnneeCap,EcaptValMin,captValMin,EcaptValMax,captValMax,EcaptZone,captZone,-1);
		}
		fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
		g_object_unref (store);
	}
}

/////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
int supprimer_capt(char ID[])

{
FILE *f;
FILE *tmp;
capteur C;
f=fopen("cap.txt","r");

tmp=fopen("tempo.txt","a+");

    if (f!=NULL)
    {

  while(fscanf(f, "%s %s %s %d %d %d %s %s %s \n" ,C.captID , C.captMarque ,
C.captType ,&C.JourCap ,&C.MoisCap,&C.AnneeCap,C.captValMin,C.captValMax,C.captZone )!=EOF)
    {
	if(strcmp(C.captID,ID)!=0)
        {fprintf(tmp,"%s %s %s %d %d %d %s %s %s \n" , C.captID , C.captMarque ,
C.captType ,C.JourCap ,C.MoisCap,C.AnneeCap,C.captValMin,C.captValMax,C.captZone );
}


    }

    }
fclose(f);
fclose(tmp);
remove("cap.txt");
rename("tempo.txt","cap.txt");
return 1;
}
//////////////////////////////////////////////////////////////////////////////////////
int modifier_capt(capteur C)
{
    char id[20];	
    char marque[20];
    char type[20];
     int jours;
    int  mois;
    int annee;
    char min[20];
    char max[20];
    char zone[20];
 
	

FILE *f;
FILE *tmp;

f=fopen("cap.txt","r");
tmp=fopen("cap1.txt","a+");
while (fscanf(f,"%s %s %s %d %d %d %s %s %s \n",id,marque,type,&jours,&mois,&annee,min,max,zone)!=EOF)
{
if (strcmp(C.captID,id)==0)
	{fprintf(tmp,"%s %s %s %d %d %d %s %s %s \n" , C.captID , C.captMarque ,
C.captType ,C.JourCap ,C.MoisCap,C.AnneeCap,C.captValMin,C.captValMax,C.captZone );
}
else
	fprintf(tmp,"%s %s %s %d %d %d %s %s %s \n",id,marque,type,jours,mois,annee,min,max,zone);
}
fclose(f);
fclose(tmp);
remove("cap.txt");
rename("cap1.txt","cap.txt");
return 1;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void rechercher_capteur(GtkWidget *liste, char ID[])

{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	char captID[20];
	char captMarque[20];
	char captType[20];
	int  JourCap;
	int MoisCap;
        int AnneeCap;
	char captValMin[20];
	char captValMax[20];
	char captZone[20];
	store=NULL;

	FILE *f;

	store=gtk_tree_view_get_model(liste);
	if(store==NULL)
	{
	renderer =gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("captID",renderer, "text",EcaptID,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column =gtk_tree_view_column_new_with_attributes("captMarque",renderer,"text",EcaptMarque,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" captType",renderer, "text", EcaptType,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" JourCap",renderer, "text", EJourCap,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("MoisCap",renderer, "text",EMoisCap,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("AnneeCap",renderer, "text",EAnneeCap,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" captValMin",renderer, "text",EcaptValMin,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("captValMax",renderer, "text",EcaptValMax,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("captZone",renderer, "text",EcaptZone,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	
	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING,  G_TYPE_STRING,  G_TYPE_STRING,  G_TYPE_INT,  G_TYPE_INT, 		G_TYPE_INT, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
	f=fopen("cap.txt","r");
	if(f==NULL)
	{
		return;
	}
	else
	{
		f= fopen("cap.txt","a+");
	 	while(fscanf(f,"%s %s %s %d %d %d %s %s %s \n",captID,captMarque,captType,&JourCap,&MoisCap,&AnneeCap,captValMin,
	captValMax,captZone )!=EOF)
	          	{
            if(strcmp(captID,ID)==0)                						  
		{
			gtk_list_store_append(store, &iter);
			gtk_list_store_set(store,&iter, EcaptID,captID,EcaptMarque,captMarque,EcaptType,captType,EJourCap,JourCap,
			EMoisCap,MoisCap,EAnneeCap,AnneeCap,EcaptValMin,captValMin,EcaptValMax,captValMax,EcaptZone,captZone,-1);
		}
                 }
		fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
		g_object_unref (store);
	}
}
}




int verif_pass(char log[], char pw[])
{
int trouve=-1;
FILE *f=NULL;
char ch1[20];
char ch2[20];
f=fopen("utilisateur.txt","r");
if (f!=NULL){
while (fscanf(f,"%s %s ",ch1,ch2)!=EOF)
{if( (strcmp(ch1,log)==0) && (strcmp(ch2,pw)==0)){
trouve=1;}
}
fclose(f);
}
return trouve;
}

void ajouter_et(Etudiant p)

{

FILE *f;
f=fopen("etudiant.txt","a+");
if (f!=NULL)
{
fprintf(f, "%s %s %s %s %s %s %s %s %s %d %d %s %s \n",p.id,p.nom,p.prenom,p.cin,p.sexe,p.date_naissance,p.gsm,p.username,p.password,p.num_etage,p.num_ch,p.type_ch,p.niveaux);

fclose(f);
}}

void afficher_ett(GtkWidget *liste )

{


GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;


store=NULL;
FILE *f;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("ID",renderer,"text",ID,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",NOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",PRENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("cin",renderer,"text",CIN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("sexe",renderer,"text",SEXE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("dns",renderer,"text",DATE_NAISSANCE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("gsm",renderer,"text",GSM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);



renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("niveaux",renderer,"text",NIVEAUX,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("username",renderer,"text",USERNAME,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("password",renderer,"text",PASSWORD,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("etage",renderer,"text",ETAGE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("chambre",renderer,"text",CHAMBRE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("type",renderer,"text",TYPE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

}
store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("util.txt","r");

    char nom[40];
    char prenom[40];
    char sexe[40];
    char date_naissance[40];
    char cin[40];
    char gsm[40];
    char niveaux[40];
    char id[40];
    char username[40];
    char password[40];
    char num_etage[40];
    char num_ch[40];
    char type_ch[40];


{
f=fopen("etudiant.txt","a+");
	while(fscanf(f, "%s %s %s %s %s %s %s %s %s %s %s %s %s \n",id,nom,prenom,cin,sexe,date_naissance,gsm,username,password,num_etage,num_ch,type_ch,niveaux)!=EOF)
	{
gtk_list_store_append(store,&iter);
	gtk_list_store_set(store,&iter,ID,id,NOM,nom,PRENOM,prenom,CIN,cin,SEXE,sexe,DATE_NAISSANCE,date_naissance,GSM,gsm
,NIVEAUX,niveaux,USERNAME,username,PASSWORD,password,ETAGE,num_etage,CHAMBRE,num_ch,TYPE,type_ch,-1);
	}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}
}




void rechercher_ett(GtkWidget *liste,char ch[30] )

{


GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;


store=NULL;
FILE *f;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("ID",renderer,"text",ID,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",NOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",PRENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("cin",renderer,"text",CIN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("sexe",renderer,"text",SEXE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("dns",renderer,"text",DATE_NAISSANCE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("gsm",renderer,"text",GSM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);



renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("niveaux",renderer,"text",NIVEAUX,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("username",renderer,"text",USERNAME,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("password",renderer,"text",PASSWORD,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("etage",renderer,"text",ETAGE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("chambre",renderer,"text",CHAMBRE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("type",renderer,"text",TYPE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


}
store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("util.txt","r");

    char nom[40];
    char prenom[40];
    char sexe[40];
    char date_naissance[40];
    char cin[40];
    char gsm[40];
    char niveaux[40];
    char id[40];
    char username[40];
    char password[40];
    char num_etage[40];
    char num_ch[40];
    char type_ch[40];


{
f=fopen("etudiant.txt","a+");
	while(fscanf(f, "%s %s %s %s %s %s %s %s %s %s %s %s %s \n",id,nom,prenom,cin,sexe,date_naissance,gsm,username,password,num_etage,num_ch,type_ch,niveaux)!=EOF)
	{if (strcmp(ch,nom)==0){
gtk_list_store_append(store,&iter);
	gtk_list_store_set(store,&iter,ID,id,NOM,nom,PRENOM,prenom,CIN,cin,SEXE,sexe,DATE_NAISSANCE,date_naissance,GSM,gsm
,NIVEAUX,niveaux,USERNAME,username,PASSWORD,password,ETAGE,num_etage,CHAMBRE,num_ch,TYPE,type_ch,-1);
	}}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}
}


void supprimer_ett (char id1[20])
{
    char nom[40];
    char prenom[40];
    char sexe[40];
    char date_naissance[40];
    char cin[40];
    char gsm[40];
    char niveaux[40];
    char id[40];
    char username[40];
    char password[40];
    char num_etage[40];
    char num_ch[40];
    char type_ch[40];
FILE*f=NULL;
FILE*f1=NULL;

f=fopen("etudiant.txt","r");
f1=fopen("ancien.txt","w+");

while(fscanf(f, "%s %s %s %s %s %s %s %s %s %s %s %s %s \n",id,nom,prenom,cin,sexe,date_naissance,gsm,username,password,num_etage,num_ch,type_ch,niveaux)!=EOF){
if(strcmp(id,id1)!=0){
fprintf(f1, "%s %s %s %s %s %s %s %s %s %s %s %s %s \n",id,nom,prenom,cin,sexe,date_naissance,gsm,username,password,num_etage,num_ch,type_ch,niveaux);
}


}

fclose(f);
fclose(f1);
remove("etudiant.txt");
rename("ancien.txt","etudiant.txt");
printf("supprimer avec succes \n");
}



void modifier_ett(char id1[],Etudiant r){
    char nom[40];
    char prenom[40];
    char sexe[40];
    char date_naissance[40];
    char cin[40];
    char gsm[40];
    char niveaux[40];
    char id[40];
    char username[40];
    char password[40];
    char num_etage[40];
    char num_ch[40];
    char type_ch[40];
FILE*f=NULL;
FILE*f1=NULL;

f=fopen("etudiant.txt","r");
f1=fopen("ancien.txt","w+");

while(fscanf(f, "%s %s %s %s %s %s %s %s %s %s %s %s %s \n",id,nom,prenom,cin,sexe,date_naissance,gsm,username,password,num_etage,num_ch,type_ch,niveaux)!=EOF){
if(strcmp(id,id1)==0){
fprintf(f1, "%s %s %s %s %s %s %s %s %s %s %s %s %s \n",id,r.nom,r.prenom,r.cin,sexe,date_naissance,r.gsm,r.username,r.password,num_etage,num_ch,type_ch,niveaux);
}
else
{
fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s \n",id,nom,prenom,cin,sexe,date_naissance,gsm,username,password,num_etage,num_ch,type_ch,niveaux);
}

}

fclose(f);
fclose(f1);
remove("etudiant.txt");
rename("ancien.txt","etudiant.txt");
printf("modifier avec succes \n");
}


int stat (char niv[20])
{int s=0;
    char nom[40];
    char prenom[40];
    char sexe[40];
    char date_naissance[40];
    char cin[40];
    char gsm[40];
    char niveaux[40];
    char id[40];
    char username[40];
    char password[40];
    char num_etage[40];
    char num_ch[40];
    char type_ch[40];
FILE*f=NULL;
FILE*f1=NULL;

f=fopen("etudiant.txt","r");


while(fscanf(f, "%s %s %s %s %s %s %s %s %s %s %s %s %s \n",id,nom,prenom,cin,sexe,date_naissance,gsm,username,password,num_etage,num_ch,type_ch,niveaux)!=EOF){
if(strcmp(niveaux,niv)==0){
s=s+1;
}


}

return s;
}







///////////////////////////////////////////////////////////////////
void ajouter(menu m)
{
FILE* f;
f=fopen("menu.txt","ab+");
fprintf(f,"%s %s %s %s %s %s %s\n",m.id,m.nom,m.type,m.entree,m.suite,m.dessert,m.date);
fclose(f);
}
/////////////////////////////////////////////////////////
void supprimer(char iden[] ){
FILE* f;
FILE* ft;
f=fopen("menu.txt","r");
ft=fopen("tmp.txt","ab+");
    char id[10];
    char date[10];
    char nom[25];
    char type[20];
    char entree[30];
    char suite[30];
    char dessert[30];
    char str[25];
while(fscanf(f,"%s %s %s %s %s %s %s\n",id,nom,type,entree,suite,dessert,date)!=EOF){
if (strcmp(iden,id)!=0){fprintf(ft,"%s %s %s %s %s %s %s\n",id,nom,type,entree,suite,dessert,date);}

}

fclose(f);
fclose(ft);
remove("menu.txt");
rename("tmp.txt","menu.txt");}
/////////////////////////////////////////////////////////////////////////////
void afficher (GtkWidget *liste){
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

    char id[10];
    char date[10];
    char nom[25];
    char type[20];
    char entree[30];
    char suite[30];
    char dessert[30];
    store=NULL;
	
FILE *f;
store=gtk_tree_view_get_model(liste);
if (store==NULL){
 	
renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("id",renderer,"text",EID,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("nom",renderer,"text",ENOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("type",renderer,"text",ETYPE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("entree",renderer,"text",EENTREE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("suite",renderer,"text",ESUITE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("dessert",renderer,"text",EDESSERT,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("date",renderer,"text",EDATE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);               }


store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

f=fopen("menu.txt","r");
while(fscanf(f,"%s %s %s %s %s %s %s\n",id,nom,type,entree,suite,dessert,date)!=EOF){
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,EID,id,ENOM,nom,ETYPE,type,EENTREE,entree,ESUITE,suite,EDESSERT,dessert,EDATE,date,-1);}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);

}
//////////////////////////////////////////////////////////////////////////
int chercher(char ident[]){
FILE *f;
f=fopen("menu.txt","r");
    int nb=0;
    char id[10];
    char date[10];
    char nom[25];
    char type[20];
    char entree[30];
    char suite[30];
    char dessert[30];
    char str[25];
while(fscanf(f,"%s %s %s %s %s %s %s\n",id,nom,type,entree,suite,dessert,date)!=EOF){
    if (strcmp(ident,id)==0) {nb+=1;}
}

if (nb!=0) return 1;
else return 0;

}	
	
/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
void vider (GtkWidget *liste){
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

    char id[10];
    char date[10];
    char nom[25];
    char type[20];
    char entree[30];
    char suite[30];
    char dessert[30];
    store=NULL;
	
FILE *f;
store=gtk_tree_view_get_model(liste);
if (store==NULL){
 	
renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("id",renderer,"text",EID,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("nom",renderer,"text",ENOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("type",renderer,"text",ETYPE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("entree",renderer,"text",EENTREE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("suite",renderer,"text",ESUITE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("dessert",renderer,"text",EDESSERT,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("date",renderer,"text",EDATE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);               }


store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);


gtk_list_store_append(store,&iter);
gtk_tree_view_set_model (GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store)); 

//g_object_unref(store); 
 }
#ifdef HAVE_CONFIG_H
#include <config.h>
#endif





//////////////////////////////////
void ajouter_produit( produit p)
{
FILE *f=NULL;
f=fopen("produit.txt","a+");//(+) creation du fichier sil nexsite pas
fprintf(f,"%s %s %s %s %s %s %s %d \n",p.id,p.nom,p.categ,p.marque,p.date_f,p.date_e,p.prix,p.quant);
fclose(f);
printf("produit ajouté avec succés \n");
}
/*
////////////////////////////////// 
void cherche_produit(char*id);
//////////////////////////////////
void supprimer_produit(char*id);
//////////////////////////////////
void modifier_produit(char id[],produit r);
////////////////////////////////// 
*/
void afficher_produit(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
		
	char id[20];
    	char nom[20];
    	char categ[20];
    	int quant;
   	char prix[20];
    	char marque[20];
    	char date_f[20];
	char date_e[20];
	store=NULL;

		
	FILE *f;
	store=gtk_tree_view_get_model(liste);

	if(store==NULL)
	{
	renderer= gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",EIDDD,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

	renderer= gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",ENOMMM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

	renderer= gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("categ",renderer,"text",ECATEGGG,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

	renderer= gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("prix",renderer,"text",EPRIXXX,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

	renderer= gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("marque",renderer,"text",EMARQUE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

	renderer= gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("date_f",renderer,"text",EDATEF,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

	renderer= gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("date_e",renderer,"text",EDATEE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

	renderer= gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("quant",renderer,"text",EQUANT,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);
	}
	store=gtk_list_store_new (COLUMNS,G_TYPE_STRING , G_TYPE_STRING , G_TYPE_STRING , G_TYPE_STRING , G_TYPE_STRING , G_TYPE_STRING , G_TYPE_STRING , G_TYPE_INT);


	f=fopen("produit.txt","r");
	if(f==NULL)
	{
		return;
	}
	else
	{
	f=fopen("produit.txt","a+");

    	while(fscanf(f,"%s %s %s %s %s %s %s %d \n",id,nom,categ,marque,date_f,date_e,prix,&quant)!=EOF)
    	{

        	gtk_list_store_append(store,&iter);
		gtk_list_store_set(store,&iter,EIDDD,id,ENOMMM,nom,ECATEGGG,categ,EPRIXXX,prix,EMARQUE,marque,EDATEF,date_f,EDATEE,date_e,EQUANT,quant,-1);
    	}
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
	g_object_unref(store);
	}
}
//////////////////////////////////
void modifier_produit(char id[],produit r)
{
    	char nom[20];
    	char categ[20];
    	int quant;
   	char prix[20];
    	char marque[20];
    	char date_f[20];
	char date_e[20];


    FILE*f=NULL;
    FILE*f1=NULL;
    produit p ;
    f=fopen("produit.txt","r");

    f1=fopen("ancien.txt","w+");

    if ((f!=NULL)&&(f1!=NULL))
        while(fscanf(f,"%s %s %s %s %s %s %s %d \n",p.id,p.nom,p.categ,p.marque,p.date_f,p.date_e,p.prix,&p.quant)!=EOF)
        {
            if( strcmp(p.id,id)==0    )
            {
                fprintf(f1,"%s %s %s %s %s %s %s %d \n",r.id,r.nom,r.categ,r.marque,r.date_f,r.date_e,r.prix,r.quant);
            }
            else
            {
                fprintf(f1,"%s %s %s %s %s %s %s %d \n",p.id,p.nom,p.categ,p.marque,p.date_f,p.date_e,p.prix,p.quant);
            }

        }
    fclose(f);
    fclose(f1);
    remove("produit.txt");
    rename("ancien.txt","produit.txt");
    printf("produit modifié avec succés \n");
}
//////////////////////////////////////
void supprimer_produit(char *id)
{

    FILE*f=NULL;
    FILE*f1=NULL;
    produit p ;
    f=fopen("produit.txt","r");
    f1=fopen("ancien.txt","w+");

    while(fscanf(f,"%s %s %s %s %s %s %s %d \n",p.id,p.nom,p.categ,p.marque,p.date_f,p.date_e,p.prix,&p.quant)!=EOF)
    {
        if(strcmp(id,p.id)!=0)
            fprintf(f1,"%s %s %s %s %s %s %s %d \n",p.id,p.nom,p.categ,p.marque,p.date_f,p.date_e,p.prix,p.quant);
    }
    fclose(f);
    fclose(f1);
    remove("produit.txt");
    rename("ancien.txt","produit.txt");
    printf("produit supprimé avec succés\n");
}
////////////////////////////////////////
void cherche_produit(char *id)
{
    FILE*f=NULL;
    produit p;
    f=fopen("produit.txt","r");
    while(fscanf(f,"%s %s %s %s %s %s %s %d \n",p.id,p.nom,p.categ,p.marque,p.date_f,p.date_e,p.prix,&p.quant)!=EOF)
    {
        if(strcmp(p.id,id)==0)
            printf("%s %s %s %s %s %s %s %d \n",p.id,p.nom,p.categ,p.marque,p.date_f,p.date_e,p.prix,p.quant);
    }
    fclose(f);

}
/////////////////////////////////
void afficher1(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter  iter;
	GtkListStore  *store;

	char id[20];
    	char nom[20];
    	char categ[20];
    	int quant;
   	char prix[20];
    	char marque[20];
    	char date_f[20];
	char date_e[20];
	store=NULL;

		
	FILE *f;
	store=gtk_tree_view_get_model(liste);

	if(store==NULL)
	{

	renderer= gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",EIDDD,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

	renderer= gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",ENOMMM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

	renderer= gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("categ",renderer,"text",ECATEGGG,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

	renderer= gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("prix",renderer,"text",EPRIXXX,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

	renderer= gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("marque",renderer,"text",EMARQUE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

	renderer= gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("date_f",renderer,"text",EDATEF,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

	renderer= gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("date_e",renderer,"text",EDATEE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

	renderer= gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("quant",renderer,"text",EQUANT,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);
	}
	store=gtk_list_store_new (COLUMNS,G_TYPE_STRING , G_TYPE_STRING , G_TYPE_STRING , G_TYPE_STRING , G_TYPE_STRING , G_TYPE_STRING , G_TYPE_STRING , G_TYPE_INT);
	f=fopen("produit.txt","r");
	if(f==NULL)
	{
		return;
	}
	else
	{
	f=fopen("produit.txt","r");

    	while(fscanf(f,"%s %s %s %s %s %s %s %d \n",id,nom,categ,marque,date_f,date_e,prix,&quant)!=EOF)
		{if (quant==0){
		
			gtk_list_store_append(store, &iter);
			gtk_list_store_set(store,&iter,EIDDD,id,ENOMMM,nom,ECATEGGG,categ,EPRIXXX,prix,EMARQUE,marque,EDATEF,date_f,EDATEE,date_e,EQUANT,quant,-1);
    	}
	fclose(f);
		gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
		g_object_unref(store);
		}
}
}
		


