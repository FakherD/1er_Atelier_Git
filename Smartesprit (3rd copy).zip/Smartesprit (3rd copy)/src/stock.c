#ifdef HAVE_CONFIG_H
#include <config.h>
#endif


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "stock.h"
#include <gtk/gtk.h>



enum
{
 EID,
 ENOM,
 ECATEG,
 EPRIX,
 EMARQUE,
 EDATEF,
 EDATEE,
 EQUANT,
 COLUMNS,
};

//////////////////////////////////
void ajouter_produit( produit p)
{
FILE *f=NULL;
f=fopen("produit.txt","a+");//(+) creation du fichier sil nexsite pas
fprintf(f,"%s %s %s %s %s %s %s %d \n",p.id,p.nom,p.categ,p.marque,p.date_f,p.date_e,p.prix,p.quant);
fclose(f);
printf("produit ajouté avec succés \n");
}
/*
////////////////////////////////// 
void cherche_produit(char*id);
//////////////////////////////////
void supprimer_produit(char*id);
//////////////////////////////////
void modifier_produit(char id[],produit r);
////////////////////////////////// 
*/
void afficher_produit(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
		
	char id[20];
    	char nom[20];
    	char categ[20];
    	int quant;
   	char prix[20];
    	char marque[20];
    	char date_f[20];
	char date_e[20];
	store=NULL;

		
	FILE *f;
	store=gtk_tree_view_get_model(liste);

	if(store==NULL)
	{
	renderer= gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",EID,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

	renderer= gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",ENOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

	renderer= gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("categ",renderer,"text",ECATEG,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

	renderer= gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("prix",renderer,"text",EPRIX,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

	renderer= gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("marque",renderer,"text",EMARQUE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

	renderer= gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("date_f",renderer,"text",EDATEF,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

	renderer= gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("date_e",renderer,"text",EDATEE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

	renderer= gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("quant",renderer,"text",EQUANT,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);
	}
	store=gtk_list_store_new (COLUMNS,G_TYPE_STRING , G_TYPE_STRING , G_TYPE_STRING , G_TYPE_STRING , G_TYPE_STRING , G_TYPE_STRING , G_TYPE_STRING , G_TYPE_INT);


	f=fopen("produit.txt","r");
	if(f==NULL)
	{
		return;
	}
	else
	{
	f=fopen("produit.txt","a+");

    	while(fscanf(f,"%s %s %s %s %s %s %s %d \n",id,nom,categ,marque,date_f,date_e,prix,&quant)!=EOF)
    	{

        	gtk_list_store_append(store,&iter);
		gtk_list_store_set(store,&iter,EID,id,ENOM,nom,ECATEG,categ,EPRIX,prix,EMARQUE,marque,EDATEF,date_f,EDATEE,date_e,EQUANT,quant,-1);
    	}
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
	g_object_unref(store);
	}
}
//////////////////////////////////
void modifier_produit(char id[],produit r)
{
    	char nom[20];
    	char categ[20];
    	int quant;
   	char prix[20];
    	char marque[20];
    	char date_f[20];
	char date_e[20];


    FILE*f=NULL;
    FILE*f1=NULL;
    produit p ;
    f=fopen("produit.txt","r");

    f1=fopen("ancien.txt","w+");

    if ((f!=NULL)&&(f1!=NULL))
        while(fscanf(f,"%s %s %s %s %s %s %s %d \n",p.id,p.nom,p.categ,p.marque,p.date_f,p.date_e,p.prix,&p.quant)!=EOF)
        {
            if( strcmp(p.id,id)==0    )
            {
                fprintf(f1,"%s %s %s %s %s %s %s %d \n",r.id,r.nom,r.categ,r.marque,r.date_f,r.date_e,r.prix,r.quant);
            }
            else
            {
                fprintf(f1,"%s %s %s %s %s %s %s %d \n",p.id,p.nom,p.categ,p.marque,p.date_f,p.date_e,p.prix,p.quant);
            }

        }
    fclose(f);
    fclose(f1);
    remove("produit.txt");
    rename("ancien.txt","produit.txt");
    printf("produit modifié avec succés \n");
}
//////////////////////////////////////
void supprimer_produit(char *id)
{

    FILE*f=NULL;
    FILE*f1=NULL;
    produit p ;
    f=fopen("produit.txt","r");
    f1=fopen("ancien.txt","w+");

    while(fscanf(f,"%s %s %s %s %s %s %s %d \n",p.id,p.nom,p.categ,p.marque,p.date_f,p.date_e,p.prix,&p.quant)!=EOF)
    {
        if(strcmp(id,p.id)!=0)
            fprintf(f1,"%s %s %s %s %s %s %s %d \n",p.id,p.nom,p.categ,p.marque,p.date_f,p.date_e,p.prix,p.quant);
    }
    fclose(f);
    fclose(f1);
    remove("produit.txt");
    rename("ancien.txt","produit.txt");
    printf("produit supprimé avec succés\n");
}
////////////////////////////////////////
void cherche_produit(char *id)
{
    FILE*f=NULL;
    produit p;
    f=fopen("produit.txt","r");
    while(fscanf(f,"%s %s %s %s %s %s %s %d \n",p.id,p.nom,p.categ,p.marque,p.date_f,p.date_e,p.prix,&p.quant)!=EOF)
    {
        if(strcmp(p.id,id)==0)
            printf("%s %s %s %s %s %s %s %d \n",p.id,p.nom,p.categ,p.marque,p.date_f,p.date_e,p.prix,p.quant);
    }
    fclose(f);

}
/////////////////////////////////
void afficher1(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
		
	char id[20];
    	char nom[20];
    	char categ[20];
    	int quant;
   	char prix[20];
    	char marque[20];
    	char date_f[20];
	char date_e[20];
	store=NULL;

		
	FILE *f;
	store=gtk_tree_view_get_model(liste);

	if(store==NULL)
	{
	renderer= gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",EID,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

	renderer= gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",ENOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

	renderer= gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("categ",renderer,"text",ECATEG,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

	renderer= gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("prix",renderer,"text",EPRIX,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

	renderer= gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("marque",renderer,"text",EMARQUE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

	renderer= gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("date_f",renderer,"text",EDATEF,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

	renderer= gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("date_e",renderer,"text",EDATEE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

	renderer= gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("quant",renderer,"text",EQUANT,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);
	}
	store=gtk_list_store_new (COLUMNS,G_TYPE_STRING , G_TYPE_STRING , G_TYPE_STRING , G_TYPE_STRING , G_TYPE_STRING , G_TYPE_STRING , G_TYPE_STRING , G_TYPE_INT);


	f=fopen("produit.txt","r");
	if(f==NULL)
	{
		return;
	}
	else
	{
	f=fopen("produit.txt","a+");

    	while(fscanf(f,"%s %s %s %s %s %s %s %d \n",id,nom,categ,marque,date_f,date_e,prix,&quant)!=EOF)
    	{if(quant==0){

        	gtk_list_store_append(store,&iter);
		gtk_list_store_set(store,&iter,EID,id,ENOM,nom,ECATEG,categ,EPRIX,prix,EMARQUE,marque,EDATEF,date_f,EDATEE,date_e,EQUANT,quant,-1);
    	}}
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
	g_object_unref(store);
	}
}
		
