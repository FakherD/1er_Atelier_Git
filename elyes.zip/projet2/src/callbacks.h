#include <gtk/gtk.h>


void
on_ebrbuttonconnect_clicked            (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ebrbuttonaficher_clicked            (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ebrbuttonajout_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ebrbuttonchercher_clicked           (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ebrbuttonmodifier_clicked           (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ebrbuttonmeilleur_clicked           (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ebrbuttonsupprimer_clicked          (GtkWidget       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_ebrbuttonajoutermenu_clicked        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ebrbuttonsupp_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ebrbuttoncherche2_clicked           (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ebrbuttonyes_clicked                (GtkWidget      *button,
                                        gpointer         user_data);

void
on_ebrbuttonenregistrer_clicked        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ebrbuttonajout1_clicked             (GtkWidget       *button,
                                        gpointer         user_data);


void
on_ebrbuttonmodifier1_clicked          (GtkWidget       *button,
                                        gpointer         user_data);

gboolean
on_ebrwindowmodifier_focus_in_event    (GtkWidget       *widget,
                                        GdkEventFocus   *event,
                                        gpointer         user_data);

void
on_ebrbuttondelete_clicked             (GtkWidget       *button,
                                        gpointer         user_data);

gboolean
on_ebrwindowconfsupp_focus_in_event    (GtkWidget       *widget,
                                        GdkEventFocus   *event,
                                        gpointer         user_data);

void
on_ebrbuttonsupp3_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ebrchecksupp_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_ebrradiop_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ebrradior_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ebrradiod_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ebrbuttonretour_clicked             (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ebrbuttonrefresh_clicked            (GtkWidget      *button,
                                        gpointer         user_data);

void
on_ebrtreeview1_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);
