#include <gtk/gtk.h>

typedef struct
{
	char captID[20];
	char captMarque[20];
	char captType[20];
         int  JourCap;
         int MoisCap;
         int AnneeCap;
	 char captValMin[20];
	 char captValMax[20];
	 char captZone[20];

}capteur;

int ajouter_capt(capteur C);
int supprimer_capt(char ID[]);
int modifier_capt(capteur C);
int exist_capteur(char *id);
void rechercher_capteur(GtkWidget *liste, char ID[]);
void afficher_capteur(GtkWidget *liste);


typedef struct
{
    char nom[40];
    char prenom[40];
    char sexe[40];
    char date_naissance[40];
    char cin[40];
    char gsm[40];
    char niveaux[40];
    char id[40];
    char username[40];
    char password[40];
    int num_etage;
    int num_ch;
    char type_ch[40];
}Etudiant;

int verif_pass(char log[], char pw[]);
void ajouter_et(Etudiant p);
void rechercher_ett(GtkWidget *liste,char ch[30] );
void supprimer_ett (char id1[20]);
void modifier_ett(char id1[],Etudiant r);




typedef struct menu{
    char id[10];
    char date[10];
    char nom[25];
    char type[20];
    char entree[30];
    char suite[30];
    char dessert[30];
}menu;
void ajouter(menu m);
void modifier(char identif[],char nouveau[],int choix);
void supprimer(char iden[] );
int chercher(char ident[]);
void afficher (GtkWidget *liste);
void meilleur();
void vider (GtkWidget *liste);



typedef struct
{
    char id[20];
    char nom[20];
    char categ[20];
    int quant;
    char prix[20];
    char marque[20];
    char date_f[20];
    char date_e[20];
} produit;
void ajouter_produit( produit p);
void cherche_produit(char*id);
void supprimer_produit(char*id);
void modifier_produit(char id[],produit r);
void afficher_produit(GtkWidget *liste);
void afficher1(GtkWidget *liste);

typedef struct
{
	char nom[20];
	char prenom[20];
	char cin[20];
	char sexe[20];
	int age;
	int num;
	char email[50];
	char poste[50];
}user;

typedef struct
{
	int j;
	int h;
	int cap;
	int val;
}alarme;

void add_user(user c);
void afficher(GtkWidget *liste);
void supp(user c);
void supp_cin( char cin[]);
int chercher_user(GtkWidget* treeview1,char*l,char*type);

void afficher_etage(GtkWidget *liste);
typedef struct
{
int jour;
int mois;
int annee;
}Datee;

typedef struct

{
char type[30];
char identifiant[30];
char problem[30];
Datee datea;
Datee dater;
}RECLAMATION;

void ajout(RECLAMATION r);
void recherche(GtkWidget* treeview1);
void suppression(char id[30], RECLAMATION r);
void affichage(GtkWidget* treeview1);
void modification(char id[30],RECLAMATION r);
int nombrer(RECLAMATION r);
int nombreh(RECLAMATION r);
