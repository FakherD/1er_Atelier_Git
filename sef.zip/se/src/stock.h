#include <gtk/gtk.h>

typedef struct
{
    char id[20];
    char nom[20];
    char categ[20];
    int quant;
    char prix[20];
    char marque[20];
    char date_f[20];
    char date_e[20];
} produit;
void ajouter_produit( produit p);
void cherche_produit(char*id);
void supprimer_produit(char*id);
void modifier_produit(char id[],produit r);
void afficher_produit(GtkWidget *liste);
void afficher1(GtkWidget *liste);
