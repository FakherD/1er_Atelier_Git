#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"
#include "arigato.h"
//#include <arigato.c>
#include <stdlib.h>
#include <string.h>
/*#include "user.h"
#include "rec.h"*/


// Agent_Fakher
char id[30],idrech[30];
GtkWidget *windowreclamationZA;
int m=0;
int a=0;
int sexe,sexem,x;
int oui=0 ,sup0=0 ,modif0=0, k=0; 
Etudiant o;
char sexe1[10]="Homme";
char zz[10]="";
int conf1=0;
int sexe,sexem,x;
int sup =0 ;
char ident1[10] ;
int choix;

void
on_FDins_clicked                       (GtkButton       *button,
                                        gpointer         user_data)
{
{
FILE *f=NULL;
GtkWidget *name, *fname, *id, *pw, *windowAuth;
char FDinscription[20];
char FDpassw[20];
char FDfname[20];
char FDid[20];
name = lookup_widget (GTK_WIDGET(button), "FDentry1");
fname = lookup_widget (GTK_WIDGET(button), "FDentry2");
id = lookup_widget (GTK_WIDGET(button), "FDentry3");
pw = lookup_widget (GTK_WIDGET(button), "FDentry4");
strcpy(FDinscription, gtk_entry_get_text(GTK_ENTRY(name)));
strcpy(FDfname, gtk_entry_get_text(GTK_ENTRY(fname)));
strcpy(FDid, gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(FDpassw, gtk_entry_get_text(GTK_ENTRY(pw)));
//ouvrir fichier
f=fopen("agentr.txt","a");
if (f!=NULL)
{
//ecrire dans le fichier
fprintf(f,"%s %s %s %s \n", FDinscription, FDpassw,FDid,FDfname);
fclose(f);
}
else 
printf("\n Not Found");
//creer la page 
windowAuth=create_FDauthent();
gtk_widget_show (windowAuth);
}
}

//////////////////////////////////////////////////////////////////////////////////////
void
on_FDlogin_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *username, *password, *windowEspaceAdmin;
char user[20],pasw[20];
int trouve=-1;
username = lookup_widget(GTK_WIDGET(button),"FDentry500");
password = lookup_widget(GTK_WIDGET(button),"FDentry600");

strcpy(user, gtk_entry_get_text(GTK_ENTRY(username)));
strcpy(pasw, gtk_entry_get_text(GTK_ENTRY(password)));

trouve = verif(user,pasw);
g_print("%d",trouve);
if (trouve=1){if (x){
windowEspaceAdmin = create_FDespaceagent ();
gtk_widget_show(windowEspaceAdmin);
}}
else if(trouve=-1)
{
g_print("hello");
}
GtkWidget *cntrl_auth;
cntrl_auth=lookup_widget(GTK_WIDGET(button),"cntrl_auth");
if (strcmp(username,"")==0)
{x=1;
gtk_widget_show(cntrl_auth);
}
else {
gtk_widget_hide(cntrl_auth);
}
if (strcmp(password,"")==0)
{x=1;
gtk_widget_show(cntrl_auth);
}
else {
gtk_widget_hide(cntrl_auth);
}
}

//////////////////////////////////////////////////////////////////////////////////////
void
on_FDaj_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *FDespaceagent;
FDespaceagent=create_FDajouter();
gtk_widget_show(FDespaceagent);
}
//////////////////////////////////////////////////////////////////////////////////////

void
on_FDmod_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *FDespaceagent;
FDespaceagent=create_FDmodifier();
gtk_widget_show(FDespaceagent);
}

//////////////////////////////////////////////////////////////////////////////////////
void
on_FDsup_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *FDespaceagent;
FDespaceagent=create_FDsupprimer();
gtk_widget_show(FDespaceagent);
}

//////////////////////////////////////////////////////////////////////////////////////
void
on_FDajo_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *input1, *input2, *input3, *input4, *input5, *input6, *input7, *input8;
GtkWidget *FD_ajouter;

produit p; 

FD_ajouter=lookup_widget(objet,"FDajouter");
input1=lookup_widget(objet,"FDentry_id");
input2=lookup_widget(objet,"FDentry_nom");
input3=lookup_widget(objet,"FDentry_pre");
input4=lookup_widget(objet,"FDentry_pr");
input5=lookup_widget(objet,"FDentry_mar");
input6=lookup_widget(objet,"FDentry_df");
input7=lookup_widget(objet,"FDentry_de");
input8=lookup_widget(objet,"FDspinbutton1");

strcpy(p.id,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(p.categ,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(p.prix,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(p.marque,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(p.date_f,gtk_entry_get_text(GTK_ENTRY(input6)));
strcpy(p.date_e,gtk_entry_get_text(GTK_ENTRY(input7)));
p.quant=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input8));

GtkWidget *cntrl_ajout;
cntrl_ajout = lookup_widget (GTK_WIDGET(objet) ,"cntrl_ajout");

//gtk_widget_hide(cntrl_ajout);
if (strcmp(p.id,"")==0)
{x=1;
gtk_widget_show(cntrl_ajout);
}
else {
gtk_widget_hide(cntrl_ajout);
}
if (strcmp(p.nom,"")==0)
{x=1;
gtk_widget_show(cntrl_ajout);
}
else {
gtk_widget_hide(cntrl_ajout);
}
if (strcmp(p.categ,"")==0)
{x=1;
gtk_widget_show(cntrl_ajout);
}
else {
gtk_widget_hide(cntrl_ajout);
}
if (strcmp(p.prix,"")==0)
{x=1;
gtk_widget_show(cntrl_ajout);
}
else {
gtk_widget_hide(cntrl_ajout);
}
if (strcmp(p.marque,"")==0)
{x=1;
gtk_widget_show(cntrl_ajout);
}
else {
gtk_widget_hide(cntrl_ajout);
}
if (strcmp(p.date_f,"")==0)
{x=1;
gtk_widget_show(cntrl_ajout);
}
else {
gtk_widget_hide(cntrl_ajout);
}
if (strcmp(p.date_e,"")==0)
{x=1;
gtk_widget_show(cntrl_ajout);
}
else {
gtk_widget_hide(cntrl_ajout);
}
if (x)
ajouter_produit( p);
}

//////////////////////////////////////////////////////////////////////////////////////
void
on_FDcherch_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *FDespaceagent;
FDespaceagent=create_FDchercher();
gtk_widget_show(FDespaceagent);
}

//////////////////////////////////////////////////////////////////////////////////////
void
on_FDaffich_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *FDafficher;
GtkWidget *FDaf_prd;




FDafficher=lookup_widget(objet,"FDafficher");
FDafficher=create_FDafficher();

gtk_widget_show(FDafficher);

FDaf_prd=lookup_widget(FDafficher,"FDaf_prd");


afficher_produit(FDaf_prd);
}

//////////////////////////////////////////////////////////////////////////////////////
void
on_FDaf_prd_row_activated              (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	
	produit p;
	GtkTreeIter iter;
	gchar *id;
	gchar *nom;
	gchar *categ;
	gchar *prix;
	gchar *marque;
	gchar *date_f;
	gchar *date_e;
	gint *quant;
	

	GtkTreeModel *model=gtk_tree_view_get_model(treeview);

	if (gtk_tree_model_get_iter(model, &iter, path))
	{
		gtk_tree_model_get (GTK_LIST_STORE(model) , &iter , 0 , &id , 1 , &nom , 2 , &categ , 3 , &prix, 4 ,&marque, 5 , &date_f , 6 , &date_e , 7 ,&quant, -1);
		strcpy(p.id,id);
		strcpy(p.nom,nom);
		strcpy(p.categ,categ);
		strcpy(p.prix,prix);
		strcpy(p.marque,marque);
		strcpy(p.date_f,date_f);
		strcpy(p.date_e,date_e);
		p.quant=quant;
		
		afficher_produit(treeview);

	}
}

//////////////////////////////////////////////////////////////////////////////////////
void
on_FDo_toggled                         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}
//////////////////////////////////////////////////////////////////////////////////////

void
on_FDn_toggled                         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}

//////////////////////////////////////////////////////////////////////////////////////
void
on_FDtrouver_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *FDrupture;
GtkWidget *FDtrrup;
GtkWidget *FDespaceagent;

FDespaceagent=lookup_widget(objet,"FDespaceagent");
gtk_widget_destroy(FDespaceagent);


//FDrupture=lookup_widget(objet,"FDrupture");
FDrupture=create_FDrupture();

gtk_widget_show(FDrupture);

FDtrrup=lookup_widget(FDrupture,"FDtrrup");


afficher1(FDtrrup);
}

//////////////////////////////////////////////////////////////////////////////////////
void
on_FDout_clicked                       (GtkButton       *button,
                                        gpointer         user_data)
{

}

//////////////////////////////////////////////////////////////////////////////////////
void
on_FDret_clicked                       (GtkButton       *button,
                                        gpointer         user_data)
{

}

//////////////////////////////////////////////////////////////////////////////////////
void
on_FDouut_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{

}

//////////////////////////////////////////////////////////////////////////////////////
void
on_FDbutton6_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

}

//////////////////////////////////////////////////////////////////////////////////////
void
on_FDbutton5_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

}


//////////////////////////////////////////////////////////////////////////////////////

void
on_FDcheckbutton1_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
	{
		oui=1;
	}

}

//////////////////////////////////////////////////////////////////////////////////////
void
on_FDbutton4_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

}

//////////////////////////////////////////////////////////////////////////////////////
void
on_FDbutton1_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
produit p;
char id[20];
GtkWidget* input1;
GtkWidget* input2;
GtkWidget* input3;
GtkWidget* input4;
GtkWidget* input5;
GtkWidget* input6;
GtkWidget* input7;
GtkWidget* input8;

input1=lookup_widget(objet_graphique,"FDentry15");
input2=lookup_widget(objet_graphique,"FDprixen");
input3=lookup_widget(objet_graphique,"FDnomen");
input4=lookup_widget(objet_graphique,"FDmaren");
input5=lookup_widget(objet_graphique,"FDcategen");
input6=lookup_widget(objet_graphique,"spinbutton1");
input7=lookup_widget(objet_graphique,"FDentry211");
input8=lookup_widget(objet_graphique,"FDentry222");

strcpy(p.id,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(p.prix,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(p.marque,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(p.categ,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(p.date_f,gtk_entry_get_text(GTK_ENTRY(input7)));
strcpy(p.date_e,gtk_entry_get_text(GTK_ENTRY(input8)));
p.quant=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input6));


GtkWidget *cntrl_modi;
cntrl_modi = lookup_widget (objet_graphique ,"cntrl_modi");

if (strcmp(p.id,"")==0)
{x=1;
gtk_widget_show(cntrl_modi);
}
else {
gtk_widget_hide(cntrl_modi);
}
if (strcmp(p.nom,"")==0)
{x=1;
gtk_widget_show(cntrl_modi);
}
else {
gtk_widget_hide(cntrl_modi);
}
if (strcmp(p.categ,"")==0)
{x=1;
gtk_widget_show(cntrl_modi);
}
else {
gtk_widget_hide(cntrl_modi);
}
if (strcmp(p.prix,"")==0)
{x=1;
gtk_widget_show(cntrl_modi);
}
else {
gtk_widget_hide(cntrl_modi);
}
if (strcmp(p.marque,"")==0)
{x=1;
gtk_widget_show(cntrl_modi);
}
else {
gtk_widget_hide(cntrl_modi);
}
if (strcmp(p.date_f,"")==0)
{x=1;
gtk_widget_show(cntrl_modi);
}
else {
gtk_widget_hide(cntrl_modi);
}
if (strcmp(p.date_e,"")==0)
{x=1;
gtk_widget_show(cntrl_modi);
}
else {
gtk_widget_hide(cntrl_modi);
}
if (x)
{
if(k==1)
{
modifier_produit(p.id,p);
}
}
}
//////////////////////////////////////////////////////////////////////////////////////
void
on_FDbutton2_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

}
//////////////////////////////////////////////////////////////////////////////////////

void
on_FDbutton3_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

}

//////////////////////////////////////////////////////////////////////////////////////
void
on_FDradiobutton1_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
	{
		sup0=1;
	}
}

//////////////////////////////////////////////////////////////////////////////////////
void
on_FDradiobutton2_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
	{
		modif0=1;
	}
}

//////////////////////////////////////////////////////////////////////////////////////
void
on_FDbutton7_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

}
//////////////////////////////////////////////////////////////////////////////////////

void
on_FDbutton66_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

}
//////////////////////////////////////////////////////////////////////////////////////

void
on_FDbutton55_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

}
//////////////////////////////////////////////////////////////////////////////////////
void
on_FDsuppp_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
produit p;
char id[20];
GtkWidget* input1, *input2;

input1=lookup_widget(objet_graphique,"FDidsup");
input2=lookup_widget(objet_graphique,"comboboxentry1");

strcpy(p.id,gtk_entry_get_text(GTK_ENTRY(input1)));

if(oui==1)
{
supprimer_produit(p.id);
oui=0;
}
}
//////////////////////////////////////////////////////////////////////////////////////

void
on_FDactiver_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
produit p;
char id[20];
GtkWidget* input1;
input1=lookup_widget(objet_graphique,"FDentry17");
strcpy(p.id,gtk_entry_get_text(GTK_ENTRY(input1)));
cherche_produit(p.id);
}



/*void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}*/

//////////////////////////////////////////////////////////////////////////////////////
void
on_FDconfirmer_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}
//////////////////////////////////////////////////////////////////////////////////////

void
on_FDtrrup_row_activated               (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
produit p;

	GtkTreeIter iter;
	gchar *id;
	gchar *nom;
	gchar *categ;
	gchar *prix;
	gchar *marque;
	gchar *date_f;
	gchar *date_e;
	gint *quant;
	

	GtkTreeModel *model=gtk_tree_view_get_model(treeview);

	if (gtk_tree_model_get_iter(model, &iter, path))
	{
		gtk_tree_model_get (GTK_LIST_STORE(model) , &iter , 0 , &id , 1 , &nom , 2 , &categ , 3 , &prix, 4 ,&marque, 5 , &date_f , 6 , &date_e , 7 ,&quant, -1);
		strcpy(p.id,id);
		strcpy(p.nom,nom);
		strcpy(p.categ,categ);
		strcpy(p.prix,prix);
		strcpy(p.marque,marque);
		strcpy(p.date_f,date_f);
		strcpy(p.date_e,date_e);
		p.quant=quant;
		
		afficher1(treeview);

	}
}
//////////////////////////////////////////////////////////////////////////////////////

//Agent_Zeineb
void
on_go_ajouter_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *afficher_et;
afficher_et=lookup_widget(GTK_WIDGET(button),"afficher_et");
gtk_widget_destroy(afficher_et);
GtkWidget *ajouter_et;
ajouter_et = create_ajouter_et ();
  gtk_widget_show (ajouter_et);
}
//////////////////////////////////////////////////////////////////////////////////////

void
on_go_supprimer_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *afficher_et;
afficher_et=lookup_widget(GTK_WIDGET(button),"afficher_et");

GtkWidget *supprimer_et;
supprimer_et = create_supprimer_et ();
  gtk_widget_show (supprimer_et);
}

//////////////////////////////////////////////////////////////////////////////////////
void
on_go_modifier_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *afficher_et;
afficher_et=lookup_widget(GTK_WIDGET(button),"afficher_et");
gtk_widget_destroy(afficher_et);

    char nom[40];
    char prenom[40];
    char sexe[40];
    char date_naissance[40];
    char cin[40];
    char gsm[40];
    char niveaux[40];
    char id[10];
    char username[40];
    char password[40];
    char num_etage[40];
    char num_ch[40];
    char type_ch[40];
FILE *f;

f=fopen("etudiant.txt","r");
GtkWidget *Modifier_et;
Modifier_et = create_Modifier_et ();
gtk_widget_show (Modifier_et);

GtkWidget *nom_et1;
nom_et1 = lookup_widget (Modifier_et ,"nom_et1");
GtkWidget *prenom_et1;
prenom_et1 = lookup_widget (Modifier_et ,"prenom_et1");
GtkWidget *cin_et1;
cin_et1 = lookup_widget (Modifier_et ,"cin_et1");
GtkWidget *tel_et1;
tel_et1 = lookup_widget (Modifier_et ,"tel_et1");
GtkWidget *username_et1;
username_et1 = lookup_widget (Modifier_et ,"username_et1");
GtkWidget *password_et1;
password_et1 = lookup_widget (Modifier_et ,"password_et1");

while(fscanf(f, "%s %s %s %s %s %s %s %s %s %s %s %s %s \n",id,nom,prenom,cin,sexe,date_naissance,gsm,username,password,num_etage,num_ch,type_ch,niveaux)!=EOF){
 if (strcmp(o.id,id)==0){
       gtk_entry_set_text(GTK_ENTRY(lookup_widget(Modifier_et,"nom_et1")),nom);
       gtk_entry_set_text(GTK_ENTRY(lookup_widget(Modifier_et,"prenom_et1")),prenom);
       gtk_entry_set_text(GTK_ENTRY(lookup_widget(Modifier_et,"cin_et1")),cin);
       gtk_entry_set_text(GTK_ENTRY(lookup_widget(Modifier_et,"tel_et1")),gsm);
       gtk_entry_set_text(GTK_ENTRY(lookup_widget(Modifier_et,"username_et1")),username);
       gtk_entry_set_text(GTK_ENTRY(lookup_widget(Modifier_et,"password_et1")),password);
}}

}
//////////////////////////////////////////////////////////////////////////////////////
void
on_actualiser_user_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview1_et;
GtkWidget *afficher_et;
afficher_et=lookup_widget(GTK_WIDGET(button),"afficher_et");
treeview1_et=lookup_widget(afficher_et,"treeview1_et");
afficher_ett(treeview1_et);
}

//////////////////////////////////////////////////////////////////////////////////////
void
on_deconn_user_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *afficher_et;
afficher_et=lookup_widget(GTK_WIDGET(button),"afficher_et");
gtk_widget_destroy(afficher_et);
GtkWidget *window1;
window1 = create_auth_et ();
gtk_widget_show (window1);
}

//////////////////////////////////////////////////////////////////////////////////////
void
on_treeview1_et_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar* id;
	gchar* nom;
	gchar* prenom;
	gchar* cin;
	gchar* sexe;
	gchar* dns;
	gchar* gsm;
	gchar* niv;
	gchar* username;
	gchar* password;
	gchar* etage;
	gchar* chambre;
	gchar* type;
	

	GtkTreeModel *model =gtk_tree_view_get_model(treeview);

	if (gtk_tree_model_get_iter(model, &iter , path))
	{ 
	  gtk_tree_model_get (GTK_LIST_STORE(model), &iter, 0 , &id, 1, &nom,2,&prenom,3,&cin,4,&sexe,5,&dns,6,&gsm,7,&niv,8,&username,9,&password,10,&etage,11,&chambre,12,&type,-1);
	strcpy(o.id,id);strcpy(zz,id);
	
	}
}
//////////////////////////////////////////////////////////////////////////////////////
void
on_chercher_et_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *cherch;
char ch[20];
GtkWidget *treeview1_user;
GtkWidget *afficher_et;
afficher_et=lookup_widget(GTK_WIDGET(button),"afficher_et");

treeview1_user=lookup_widget(afficher_et,"treeview1_et");
cherch = lookup_widget (GTK_WIDGET(button) ,"entry1_chercher");
strcpy(ch, gtk_entry_get_text(GTK_ENTRY(cherch)));
 rechercher_ett(treeview1_user,ch);
}
//////////////////////////////////////////////////////////////////////////////////////
void
on_ajouter_et_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
int aa,mm,jj;
char a[3];
char b[3];
char c[6];
char y[15]="";

int x=0;
Etudiant p;
GtkWidget *calendar1_et;
GtkWidget *id_et,*nom_et,*prenom_et,*cin_et,*tel_et,*comboboxentry1_et,*comboboxentry2_et;
GtkWidget *spinbutton1_et;
GtkWidget *username_et,*password_et,*cin_user,*num_etage,*num_ch;

calendar1_et=lookup_widget(GTK_WIDGET(button),"calendar1_et");

nom_et=lookup_widget(GTK_WIDGET(button),"entre_nomet");
prenom_et=lookup_widget(GTK_WIDGET(button),"entre_prenom_et");
cin_et=lookup_widget(GTK_WIDGET(button),"entre_cinet");
tel_et=lookup_widget(GTK_WIDGET(button),"entre_telet");
password_et=lookup_widget(GTK_WIDGET(button),"entre_passwordet");
username_et=lookup_widget(GTK_WIDGET(button),"entre_usernameet");


comboboxentry1_et=lookup_widget(GTK_WIDGET(button),"comboboxentry1_et");
comboboxentry2_et=lookup_widget(GTK_WIDGET(button),"comboboxentry2_et");
id_et=lookup_widget(GTK_WIDGET(button),"entre_id");
num_etage=lookup_widget(GTK_WIDGET(button),"spinbutton2_et");
num_ch=lookup_widget(GTK_WIDGET(button),"spinbutton3_et");


GtkWidget *e_id;
e_id = lookup_widget (GTK_WIDGET(button) ,"e_id");
GtkWidget *e_nom;
e_nom = lookup_widget (GTK_WIDGET(button) ,"e_nom");
GtkWidget *e_prenom;
e_prenom = lookup_widget (GTK_WIDGET(button) ,"e_prenom");
GtkWidget *e_cin;
e_cin = lookup_widget (GTK_WIDGET(button),"e_cin");
GtkWidget *e_num;
e_num = lookup_widget (GTK_WIDGET(button) ,"e_num");
GtkWidget *e_username;
e_username = lookup_widget (GTK_WIDGET(button) ,"e_username");
GtkWidget *e_password;
e_password = lookup_widget (GTK_WIDGET(button) ,"e_password");
GtkWidget *e_niveaux;
e_niveaux = lookup_widget (GTK_WIDGET(button) ,"e_niveaux");
GtkWidget *e_typeet;
e_typeet = lookup_widget (GTK_WIDGET(button) ,"e_typeet");
GtkWidget *e_confet;
e_confet = lookup_widget (GTK_WIDGET(button) ,"e_confet");
int bbb=0;
gtk_calendar_get_date (GTK_CALENDAR(calendar1_et),
                       &aa,
                       &mm,
                       &jj);

mm=mm+1;

sprintf(a,"%d",jj);sprintf(b,"%d",mm);sprintf(c,"%d",aa);
strcat(y,a);strcat(y,"-");strcat(y,b);strcat(y,"-");strcat(y,c);


p.num_etage=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(num_etage));
p.num_ch=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(num_ch));

strcpy(p.id,gtk_entry_get_text(GTK_ENTRY(id_et)));
strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(nom_et)));
strcpy(p.prenom,gtk_entry_get_text(GTK_ENTRY(prenom_et)));
strcpy(p.cin,gtk_entry_get_text(GTK_ENTRY(cin_et)));
strcpy(p.gsm,gtk_entry_get_text(GTK_ENTRY(tel_et)));
strcpy(p.username,gtk_entry_get_text(GTK_ENTRY(username_et)));
strcpy(p.password,gtk_entry_get_text(GTK_ENTRY(password_et)));



strcpy(p.date_naissance,y);
strcpy(p.niveaux,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxentry1_et)));
strcpy(p.type_ch,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxentry2_et)));

strcpy(p.sexe,sexe1);

if (strcmp(p.id,"")==0)
{x=1;
gtk_widget_show(e_id);
}
else {x=0;
gtk_widget_hide(e_id);
}
if (strcmp(p.nom,"")==0)
{x=1;
gtk_widget_show(e_nom);
}
else {x=0;
gtk_widget_hide(e_nom);
}
if (strcmp(p.prenom,"")==0)
{x=1;
gtk_widget_show(e_prenom);
}
else {x=0;
gtk_widget_hide(e_prenom);
}
if (strcmp(p.cin,"")==0)
{x=1;
gtk_widget_show(e_cin);
}
else {x=0;
gtk_widget_hide(e_cin);
}
if (strcmp(p.gsm,"")==0)
{x=1;
gtk_widget_show(e_num);
}
else {x=0;
gtk_widget_hide(e_num);
}
if (strcmp(p.username,"")==0)
{x=1;
gtk_widget_show(e_username);
}
else {x=0;
gtk_widget_hide(e_username);
}
if (strcmp(p.password,"")==0)
{x=1;
gtk_widget_show(e_password);
}
else {x=0;
gtk_widget_hide(e_password);
}
if (strcmp(p.niveaux,"")==0)
{x=1;
gtk_widget_show(e_niveaux);
}
else {x=0;
gtk_widget_hide(e_niveaux);
}
if (strcmp(p.type_ch,"")==0)
{x=1;
gtk_widget_show(e_typeet);
}
else {x=0;
gtk_widget_hide(e_typeet);
}
if (conf1==0)
{x=1;
gtk_widget_show(e_confet);
}
else {
gtk_widget_hide(e_confet);
}

if(x==0){
ajouter_et(p);
GtkWidget *ajouter_et;
ajouter_et=lookup_widget(GTK_WIDGET(button),"ajouter_et");
gtk_widget_destroy(ajouter_et);
GtkWidget *afficher_et;
afficher_et = create_afficher_et ();
  gtk_widget_show (afficher_et);
}}



//////////////////////////////////////////////////////////////////////////////////////
void
on_modifier_et_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{


Etudiant p;


GtkWidget *nom_et1;
nom_et1 = lookup_widget (GTK_WIDGET(button),"nom_et1");
GtkWidget *prenom_et1;
prenom_et1 = lookup_widget (GTK_WIDGET(button),"prenom_et1");
GtkWidget *cin_et1;
cin_et1 = lookup_widget (GTK_WIDGET(button),"cin_et1");
GtkWidget *tel_et1;
tel_et1 = lookup_widget (GTK_WIDGET(button) ,"tel_et1");
GtkWidget *username_et1;
username_et1 = lookup_widget (GTK_WIDGET(button) ,"username_et1");
GtkWidget *password_et1;
password_et1 = lookup_widget (GTK_WIDGET(button) ,"password_et1");


GtkWidget *e_nom;
e_nom = lookup_widget (GTK_WIDGET(button) ,"e_nom1");
GtkWidget *e_prenom;
e_prenom = lookup_widget (GTK_WIDGET(button),"e_prenom1");
GtkWidget *e_cin;
e_cin = lookup_widget (GTK_WIDGET(button) ,"e_cin1");
GtkWidget *e_num;
e_num = lookup_widget (GTK_WIDGET(button) ,"e_tel1");
GtkWidget *e_username;
e_username = lookup_widget (GTK_WIDGET(button) ,"e_username1");
GtkWidget *e_password;
e_password = lookup_widget (GTK_WIDGET(button),"e_password1");


int x=0;

strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(nom_et1)));
strcpy(p.prenom,gtk_entry_get_text(GTK_ENTRY(prenom_et1)));
strcpy(p.cin,gtk_entry_get_text(GTK_ENTRY(cin_et1)));
strcpy(p.gsm,gtk_entry_get_text(GTK_ENTRY(tel_et1)));
strcpy(p.username,gtk_entry_get_text(GTK_ENTRY(username_et1)));
strcpy(p.password,gtk_entry_get_text(GTK_ENTRY(password_et1)));
if (strcmp(p.nom,"")==0)
{x=1;
gtk_widget_show(e_nom);
}
else {x=0;
gtk_widget_hide(e_nom);
}
if (strcmp(p.prenom,"")==0)
{x=1;
gtk_widget_show(e_prenom);
}
else {x=0;
gtk_widget_hide(e_prenom);
}
if (strcmp(p.cin,"")==0)
{x=1;
gtk_widget_show(e_cin);
}
else {x=0;
gtk_widget_hide(e_cin);
}
if (strcmp(p.gsm,"")==0)
{x=1;
gtk_widget_show(e_num);
}
else {x=0;
gtk_widget_hide(e_num);
}
if (strcmp(p.username,"")==0)
{x=1;
gtk_widget_show(e_username);
}
else {x=0;
gtk_widget_hide(e_username);
}
if (strcmp(p.password,"")==0)
{x=1;
gtk_widget_show(e_password);
}
else {x=0;
gtk_widget_hide(e_password);
}


if (x==0){

 modifier_ett(o.id,p);
GtkWidget *Modifier_et;
Modifier_et=lookup_widget(button,"Modifier_et");
gtk_widget_destroy(Modifier_et);
GtkWidget *afficher_et;
afficher_et = create_afficher_et ();
  gtk_widget_show (afficher_et);

}}

//////////////////////////////////////////////////////////////////////////////////////
void
on_retour_ajouteret_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ajouter_et;
ajouter_et=lookup_widget(GTK_WIDGET(button),"ajouter_et");
gtk_widget_destroy(ajouter_et);
GtkWidget *afficher_et;
afficher_et = create_afficher_et ();
  gtk_widget_show (afficher_et);
}


void
on_retour_modifier_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Modifier_et;
Modifier_et=lookup_widget(GTK_WIDGET(button),"Modifier_et");
gtk_widget_destroy(Modifier_et);
GtkWidget *afficher_et;
afficher_et = create_afficher_et ();
  gtk_widget_show (afficher_et);
}

//////////////////////////////////////////////////////////////////////////////////////
void
on_annuler_supp_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *supprimer_et;
supprimer_et=lookup_widget(GTK_WIDGET(button),"supprimer_et");
gtk_widget_destroy(supprimer_et);
GtkWidget *afficher_et;
  gtk_widget_show (afficher_et);
}

//////////////////////////////////////////////////////////////////////////////////////
void
on_conf_supp_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
supprimer_ett(o.id);
GtkWidget *supprimer_et;
supprimer_et=lookup_widget(GTK_WIDGET(button),"supprimer_et");
gtk_widget_destroy(supprimer_et);
GtkWidget *afficher_et;
  gtk_widget_show (afficher_et);
}

//////////////////////////////////////////////////////////////////////////////////////
void
on_radiobutton1_et_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
strcpy(sexe1,"Homme");
}
//////////////////////////////////////////////////////////////////////////////////////

void
on_radiobutton2_et_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
strcpy(sexe1,"Femme");
}

//////////////////////////////////////////////////////////////////////////////////////
void
on_ZAcheckbutton1_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
conf1=1;
}

//////////////////////////////////////////////////////////////////////////////////////
void
on_auth_et_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *erreur_pass;
erreur_pass = lookup_widget(GTK_WIDGET(button),"e_auth");

GtkWidget *username, *password, *windowAcceuil_hsm;
char user[20];
char passw[20];
int trouve;
username = lookup_widget (GTK_WIDGET(button), "username_et");
password = lookup_widget (GTK_WIDGET(button), "password_et");
strcpy(user ,gtk_entry_get_text ( GTK_ENTRY(username)));
strcpy(passw ,gtk_entry_get_text ( GTK_ENTRY(password)));
trouve=verif_pass(user,passw);
if (trouve==1)
{

GtkWidget *window1;
window1=lookup_widget(GTK_WIDGET(button),"auth_et");
gtk_widget_destroy(window1);
GtkWidget *afficher_et;
afficher_et = create_afficher_et ();
  gtk_widget_show (afficher_et);
}
else if (trouve==-1){gtk_widget_show (erreur_pass);}
}


void
on_inns_ett_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1;
window1=lookup_widget(GTK_WIDGET(button),"auth_et");
gtk_widget_destroy(window1);
GtkWidget *inscri_et;
inscri_et = create_inscri_et ();
  gtk_widget_show (inscri_et);
}
//////////////////////////////////////////////////////////////////////////////////////

void
on_insc_et_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
FILE *f=NULL;
GtkWidget *login, *pw;
char login1[40];
char passw[40];
login = lookup_widget(GTK_WIDGET(button),"entry1_ett");
pw = lookup_widget(GTK_WIDGET(button),"entry2_ett");
strcpy(login1,gtk_entry_get_text(GTK_ENTRY(login)));
strcpy(passw,gtk_entry_get_text(GTK_ENTRY(pw)));
f=fopen("utilisateur.txt","a+");
if (f != NULL)
{
fprintf(f,"%s %s \n",login1,passw);

}
fclose(f);
GtkWidget *inscri_et;
inscri_et=lookup_widget(GTK_WIDGET(button),"inscri_et");
gtk_widget_destroy(inscri_et);
GtkWidget *auth_et;
auth_et = create_auth_et ();
  gtk_widget_show (auth_et);

}

//////////////////////////////////////////////////////////////////////////////////////
void
on_anul_ins_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *inscri_et;
inscri_et=lookup_widget(GTK_WIDGET(button),"inscri_et");
gtk_widget_destroy(inscri_et);
GtkWidget *auth_et;
auth_et = create_auth_et ();
  gtk_widget_show (auth_et);
}

//////////////////////////////////////////////////////////////////////////////////////
void
on_stat_etttttt_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
char nnn[20];
char a[20];
int s;
GtkWidget *comboboxentry3_et;
comboboxentry3_et=lookup_widget(button,"comboboxentry3_et");

GtkWidget *nbr_ettt;
nbr_ettt=lookup_widget(GTK_WIDGET(button),"nbr_ettt");

strcpy(nnn,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxentry3_et)));
s = stat(nnn);

sprintf(a,"%d",s);
gtk_label_set_text(GTK_LABEL(nbr_ettt),a);
}
//////////////////////////////////////////////////////////////////////////////////////

// CAPTEUR_Maram
void
on_ajouter1_clicked                   ( GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{   GtkWidget* fenetre_ajout;
     GtkWidget* fenetre_princ;
fenetre_ajout=lookup_widget (objet_graphique,"window2");
fenetre_ajout=create_window2 ();
gtk_widget_show(fenetre_ajout);
afficher_capteur(fenetre_ajout);
fenetre_princ=lookup_widget (objet_graphique,"window1");
gtk_widget_destroy(fenetre_princ);
}

///////////////////////////////////////////////////////////////////////

void
on_modifier1_clicked                   ( GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{ GtkWidget *fenetre_mod;
    GtkWidget *fenetre_princ;
fenetre_mod=lookup_widget (objet_graphique,"window2");
fenetre_mod=create_window2 ();
gtk_widget_show(fenetre_mod);
afficher_capteur(fenetre_mod);
fenetre_princ=lookup_widget (objet_graphique,"window1");
gtk_widget_destroy(fenetre_princ);

}

////////////////////////////////////////////////////////////////////////
void
on_supprimer1_clicked                  ( GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{  GtkWidget *fenetre_supp;
    GtkWidget *fenetre_princ;
fenetre_supp=lookup_widget (objet_graphique,"window3");
fenetre_supp=create_window3();
gtk_widget_show(fenetre_supp);
afficher_capteur(fenetre_supp);
fenetre_princ=lookup_widget (objet_graphique,"window1");
gtk_widget_destroy(fenetre_princ);

}

////////////////////////////////////////////////////////////////////////////
void
on_consulter_clicked                  ( GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{ GtkWidget *fenetre_ajout;
GtkWidget *fenetre_afficher;
  GtkWidget *fenetre_princ;
GtkWidget *treeview1;

fenetre_ajout=lookup_widget(objet_graphique,"window1");

gtk_widget_destroy(fenetre_ajout);
fenetre_afficher=lookup_widget(objet_graphique,"window4");
fenetre_afficher=create_window4();

gtk_widget_show(fenetre_afficher);


treeview1=lookup_widget(fenetre_afficher,"treeview1");

afficher_capteur(treeview1);
fenetre_princ=lookup_widget (objet_graphique,"window1");
gtk_widget_destroy(fenetre_princ);

}

///////////////////////////////////////////////////////////////////////////////////
int x;
int a;
void
on_ajout_clicked                        (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{  capteur C;
   GtkWidget *IdentifianteCapt;
   GtkWidget *MarqueCapt;
   GtkWidget *TypeCapt;
   GtkWidget *JourCapt;
   GtkWidget *MoisCapt;
   GtkWidget *AnneeCapt;
   GtkWidget *ComboboxValeurMini;
   GtkWidget *ComboboxValeurMaxi;
   GtkWidget *ComboboxZoCov;
   GtkWidget *outputMsg;
   int ajout,verif;
   char text[200];
  
  
  
GtkWidget *fenetre_ajout;

fenetre_ajout=lookup_widget(objet_graphique,"window2");
IdentifianteCapt=lookup_widget(objet_graphique,"entry_id");
MarqueCapt=lookup_widget(objet_graphique,"entry_mq");
strcpy(C.captID,gtk_entry_get_text(GTK_ENTRY(IdentifianteCapt)));
strcpy(C.captMarque,gtk_entry_get_text(GTK_ENTRY(MarqueCapt)));
/////////////////////////////////////////////////////////
JourCapt=lookup_widget(objet_graphique,"spinbutton1");
MoisCapt=lookup_widget(objet_graphique,"spinbutton2");
AnneeCapt=lookup_widget(objet_graphique,"spinbutton3");
C.JourCap=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(JourCapt));
C.MoisCap=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(MoisCapt));
C.AnneeCap=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(AnneeCapt));
///////////////////////////////////////////////////////////
ComboboxValeurMaxi=lookup_widget(objet_graphique,"combobox_max");
ComboboxValeurMini=lookup_widget(objet_graphique,"combobox_min");
ComboboxZoCov=lookup_widget(objet_graphique,"combobox7");
strcpy(C.captValMin,gtk_combo_box_get_active_text(GTK_COMBO_BOX(ComboboxValeurMini)));
strcpy(C.captValMax,gtk_combo_box_get_active_text(GTK_COMBO_BOX(ComboboxValeurMaxi)));
strcpy(C.captZone,gtk_combo_box_get_active_text(GTK_COMBO_BOX(ComboboxZoCov)));
///////////////////////////////////////////////////////////////////////////
if(x==1)
{strcpy(C.captType,"Temperature");}
else
if(x==2)
{strcpy(C.captType,"Mouvement");}
       
//ajout=ajouter_capt(C);

verif=exist_capteur(C.captID);

switch(verif)
    
{
    case 0:  
    { ajout=ajouter_capt(C); 
     strcpy (text,"Ajout Réussi");
     outputMsg=lookup_widget(objet_graphique,("Msg"));
     gtk_label_set_text(GTK_LABEL(outputMsg),text);
     }
    break;
    case 1:
    { strcpy (text,"Identifiant déja existe");
    outputMsg=lookup_widget(objet_graphique,("Msg"));
    gtk_label_set_text(GTK_LABEL(outputMsg),text);
    }
    break;
}
 }
//////////////////////////////////////////////////////////////////////
void
on_modif_clicked                      (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{   capteur C;
   GtkWidget *IdentifianteCapt;
   GtkWidget *MarqueCapt;
   GtkWidget *TypeCapt;
   GtkWidget *JourCapt;
   GtkWidget *MoisCapt;
   GtkWidget *AnneeCapt;
   GtkWidget *ComboboxValeurMini;
   GtkWidget *ComboboxValeurMaxi;
   GtkWidget *ComboboxZoCov;
   GtkWidget *outputMsg;
   int mod,verif;
   char text[200];
  
   
GtkWidget *fenetre_ajout;

fenetre_ajout=lookup_widget(objet_graphique,"window2");
IdentifianteCapt=lookup_widget(objet_graphique,"entry_id");
MarqueCapt=lookup_widget(objet_graphique,"entry_mq");
strcpy(C.captID,gtk_entry_get_text(GTK_ENTRY(IdentifianteCapt)));
strcpy(C.captMarque,gtk_entry_get_text(GTK_ENTRY(MarqueCapt)));
/////////////////////////////////////////////////////////
JourCapt=lookup_widget(objet_graphique,"spinbutton1");
MoisCapt=lookup_widget(objet_graphique,"spinbutton2");
AnneeCapt=lookup_widget(objet_graphique,"spinbutton3");
C.JourCap=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(JourCapt));
C.MoisCap=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(MoisCapt));
C.AnneeCap=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(AnneeCapt));
///////////////////////////////////////////////////////////
ComboboxValeurMaxi=lookup_widget(objet_graphique,"combobox_max");
ComboboxValeurMini=lookup_widget(objet_graphique,"combobox_min");
ComboboxZoCov=lookup_widget(objet_graphique,"combobox7");
strcpy(C.captValMin,gtk_combo_box_get_active_text(GTK_COMBO_BOX(ComboboxValeurMini)));
strcpy(C.captValMax,gtk_combo_box_get_active_text(GTK_COMBO_BOX(ComboboxValeurMaxi)));
strcpy(C.captZone,gtk_combo_box_get_active_text(GTK_COMBO_BOX(ComboboxZoCov)));
///////////////////////////////////////////////////////////////////////////
if(x==1)
{strcpy(C.captType,"Temperature");}
else
if(x==2)
{strcpy(C.captType,"Mouvement");}
 // mod=modifier_capt(C); 
verif=exist_capteur(C.captID);

switch(verif)
    
{
    case 0:  
    { strcpy (text,"Identifiant n'existe pas");
    outputMsg=lookup_widget(objet_graphique,("Msg"));
    gtk_label_set_text(GTK_LABEL(outputMsg),text);
    }
    break;
    case 1:
   
    {  mod=modifier_capt(C);
     strcpy (text,"Modifie Réussi");
     outputMsg=lookup_widget(objet_graphique,("Msg"));
     gtk_label_set_text(GTK_LABEL(outputMsg),text);
     }
    break; 
    break;
} 

}
///////////////////////////////////////////////////////////////////////////////////////

void
on_button_affich1_clicked               ( GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{  GtkWidget *fenetre_ajout;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;

fenetre_ajout=lookup_widget(objet_graphique,"window2");

gtk_widget_destroy(fenetre_ajout);
fenetre_afficher=lookup_widget(objet_graphique,"window4");
fenetre_afficher=create_window4();

gtk_widget_show(fenetre_afficher);


treeview1=lookup_widget(fenetre_afficher,"treeview1");

afficher_capteur(treeview1);

gtk_widget_destroy(fenetre_ajout);

}

////////////////////////////////////////////////////////////////////////////////
void
on_button7_ret_clicked                ( GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{ GtkWidget *fenetre_principale, *fenetre_ajout_modif;
fenetre_ajout_modif=lookup_widget(objet_graphique,"window2");
fenetre_principale=lookup_widget(objet_graphique,"window1");

gtk_widget_destroy(fenetre_ajout_modif);
fenetre_principale=create_window1();
gtk_widget_show(fenetre_principale);

}

int conf=0;
int *r=&conf;
void
on_supp_clicked                      ( GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{    GtkWidget *input1;
          
     GtkWidget  *fenetre_supp;
     GtkWidget *outputMsg;
     int supp,verif;
     char text[200];
    char ID[20];
     

fenetre_supp=lookup_widget(objet_graphique,"window3");
input1=lookup_widget(objet_graphique,"entry_supp");   
strcpy(ID,gtk_entry_get_text(GTK_ENTRY(input1)));
if(conf)
//supp=supprimer_capt(ID);

{verif=exist_capteur(ID);


switch(verif)
    
{
    case 0:
   
     
    { strcpy (text,"Identifiant à supprimer n'existe pas");
    outputMsg=lookup_widget(objet_graphique,("label51"));
    gtk_label_set_text(GTK_LABEL(outputMsg),text);
    }
  
    break;
    case 1:
     
     {
      supp=supprimer_capt(ID);
     strcpy (text,"Suppression Réussi");
     outputMsg=lookup_widget(objet_graphique,("label53"));
     gtk_label_set_text(GTK_LABEL(outputMsg),text);
     }
    
    break; 
    break;
}
}
else 
{strcpy (text,"La confirmation est obligatoire!");
    outputMsg=lookup_widget(objet_graphique,("label52"));
    gtk_label_set_text(GTK_LABEL(outputMsg),text);
}
}

/////////////////////////////////////////////////////////////////////////////////////
void
on_button10_affich_clicked             ( GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{  GtkWidget *fenetre_supp;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;
fenetre_afficher=lookup_widget(objet_graphique,"window4");
fenetre_afficher=create_window4();

gtk_widget_show(fenetre_afficher);


treeview1=lookup_widget(fenetre_afficher,"treeview1");

afficher_capteur(treeview1);
fenetre_supp=lookup_widget(objet_graphique,"window3");
gtk_widget_destroy(fenetre_supp);


}

//////////////////////////////////////////////////////////////////////////////////
void
on_button9_ret_clicked                  ( GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{  GtkWidget *fenetre_principale, *fenetre_ajout_supp;
fenetre_ajout_supp=lookup_widget(objet_graphique,"window3");
fenetre_principale=lookup_widget(objet_graphique,"window1");

gtk_widget_destroy(fenetre_ajout_supp);
fenetre_principale=create_window1();
gtk_widget_show(fenetre_principale);

}

//////////////////////////////////////////////////////////////////////////////////
void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{  GtkTreeIter iter;
	gchar *captID;
	gchar *captMarque; 
	gchar *captType; 
	gchar *JourCap; 
	gchar *MoisCap;
	gchar *AnneeCap; 
        gchar *captValMin;
        gchar *captValMax;
	gchar *captZone;
	capteur C;
	FILE *f=NULL;


	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model,&iter,path))
	{gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&captID,1,&captMarque,2,&captType,3,&JourCap,4,&MoisCap,5,&AnneeCap,6,&captValMin,7,&captValMax,8,&captZone,-1);

	strcpy(C.captID,captID);
	strcpy(C.captMarque,captMarque);
	strcpy(C.captType,captType);
	C.JourCap = JourCap;
	C.MoisCap = MoisCap;
	C.AnneeCap=AnneeCap;
	strcpy(C.captValMin,captValMin);
	strcpy(C.captValMax,captValMax);
	strcpy(C.captZone,captZone);
        afficher_capteur(treeview);

}
}
///////////////////////////////////////////////////////////////////////////////////////////
void
on_recherche_clicked                    ( GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
 GtkWidget *Fenetrerech;
   GtkWidget *idy;
   GtkWidget *treeviewrech;
      GtkWidget *outputMsg;
   int verif;
    char text[200];
   char id[20];
   
Fenetrerech=lookup_widget(objet_graphique,"window4");
idy=lookup_widget(objet_graphique,"entry_rech");
treeviewrech=lookup_widget(objet_graphique,"treeview2_rech");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(idy)));
verif=exist_capteur(id);

switch(verif)
    
{
    case 0:  
    { strcpy (text,"Identifiant n'existe pas");
    outputMsg=lookup_widget(objet_graphique,("label64"));
    gtk_label_set_text(GTK_LABEL(outputMsg),text);
    }
    break;
    case 1:
   
    {  rechercher_capteur(treeviewrech, id);
       remove(treeviewrech);
       strcpy (text,"Identifiant existe");
       outputMsg=lookup_widget(objet_graphique,("label64"));
       gtk_label_set_text(GTK_LABEL(outputMsg),text);
      }
    break; 
    break;
} 
}

///////////////////////////////////////////////////////////////////////////////////////////////
void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
x=1;
}
}

//////////////////////////////////////////////////////////////////////////////////////////////
void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
x=2;
}
}

//////////////////////////////////////////////////////////////////////////////////////////////

void
on_button7_clicked                      (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{  GtkWidget *fenetre_principale, *fenetre_aff;
fenetre_aff=lookup_widget(objet_graphique,"window4");
fenetre_principale=lookup_widget(objet_graphique,"window1");

gtk_widget_destroy(fenetre_aff);
fenetre_principale=create_window1();
gtk_widget_show(fenetre_principale);

}
//////////////////////////////////////////////////////////////////////////////////////////////

void
on_treeview2_rech_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
  GtkTreeIter iter;
	gchar *captID;
	gchar *captMarque; 
	gchar *captType; 
	gchar *JourCap; 
	gchar *MoisCap;
	gchar *AnneeCap; 
        gchar *captValMin;
        gchar *captValMax;
	gchar *captZone;
	capteur C;
	FILE *f=NULL;


	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model,&iter,path))
	{gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&captID,1,&captMarque,2,&captType,3,&JourCap,4,&MoisCap,5,&AnneeCap,6,&captValMin,7,&captValMax,8,&captZone,-1);

	strcpy(C.captID,captID);
	strcpy(C.captMarque,captMarque);
	strcpy(C.captType,captType);
	C.JourCap=JourCap;
	C.MoisCap=MoisCap;
	C.AnneeCap=AnneeCap;
	strcpy(C.captValMin,captValMin);
	strcpy(C.captValMax,captValMax);
	strcpy(C.captZone,captZone);
        afficher_capteur(treeview);

}

}

/////////////////////////////////////////////////////////////////////////////////////////////
void
on_button8_actu_clicked                  (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{GtkWidget  *fenetre_aff,*treeview;
fenetre_aff=create_window4();
gtk_widget_show(fenetre_aff);
treeview=lookup_widget(fenetre_aff,"treeview1");
afficher_capteur(treeview);

fenetre_aff=lookup_widget(objet_graphique,"window4");

gtk_widget_destroy(fenetre_aff);

}
//////////////////////////////////////////////////////////////////////////////////////////////

void
on_button8_al_clicked                  (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
  GtkWidget *fenetre_al;
  GtkWidget *fenetre_princ;
fenetre_al=lookup_widget (objet_graphique,"window5");
fenetre_al=create_window5 ();
gtk_widget_show(fenetre_al);
afficher_capteur(fenetre_al);
fenetre_princ=lookup_widget (objet_graphique,"window1");
gtk_widget_destroy(fenetre_princ);

}

//////////////////////////////////////////////////////////////////////////////////////////////
void
on_button9_tm_clicked                  (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
  GtkWidget *ValeurtmpMin1;
   GtkWidget *ValeurtmpMin2;
   GtkWidget *ValeurtmpMax1;
   GtkWidget *ValeurtmpMax2;
      GtkWidget *output;
int id ,n=1 ,i, j , a,mo,nt,ct [50];
float val;
char texte [200]="";
//float max2=60 , min2=40,max1=0, min1=-10;
float max2,max1,min1,min2;

ValeurtmpMin1=lookup_widget(objet_graphique,"spinbutton4");
ValeurtmpMin2=lookup_widget(objet_graphique,"spinbutton5");
ValeurtmpMax1=lookup_widget(objet_graphique,"spinbutton6");
ValeurtmpMax2=lookup_widget(objet_graphique,"spinbutton7");
min1=gtk_spin_button_get_value_as_float(GTK_SPIN_BUTTON(ValeurtmpMin1));
min2=gtk_spin_button_get_value_as_float(GTK_SPIN_BUTTON(ValeurtmpMin2));
max1=gtk_spin_button_get_value_as_float(GTK_SPIN_BUTTON(ValeurtmpMax1));
max2=gtk_spin_button_get_value_as_float(GTK_SPIN_BUTTON(ValeurtmpMax2));
FILE *f; 
f= fopen ("temperature.txt","r");
if (f!=NULL) {
while(fscanf (f,"%d %d %d %d %f",&id,&j,&mo ,&a, &val)!=EOF){
	if ((val<max1 && val>min1)||(val<max2 && val>min2)) {
		i =0;
while ((i <n) && (ct[i]!=id ))
i++;
if (i==n) {ct[i]=id ; n++ ;}} }
sprintf (texte,"il y a : %d capteurs de temperature alarmentes ",n);
output=lookup_widget(objet_graphique,("label45"));
gtk_label_set_text(GTK_LABEL(output),texte);
fclose (f);
return (n);
}
}

/////////////////////////////////////////////////////////////////////////////////////////////

void
on_button10_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{   GtkWidget *ValeurhumMin1;
   GtkWidget *ValeurhumMin2;
   GtkWidget *ValeurhumMax1;
   GtkWidget *ValeurhumMax2;
      GtkWidget *output;
//float max2=100 , min2=1,max1=300 , min1=10;
int id ,n=1 ,i, j , a,mo,nh,ch [50];
float val;
char texte [200]="";
float max2,max1,min1,min2;
ValeurhumMin1=lookup_widget(objet_graphique,"spinbutton8");
ValeurhumMin2=lookup_widget(objet_graphique,"spinbutton9");
ValeurhumMax1=lookup_widget(objet_graphique,"spinbutton10");
ValeurhumMax2=lookup_widget(objet_graphique,"spinbutton11");
min1=gtk_spin_button_get_value_as_float(GTK_SPIN_BUTTON(ValeurhumMin1));
min2=gtk_spin_button_get_value_as_float(GTK_SPIN_BUTTON(ValeurhumMin2));
max1=gtk_spin_button_get_value_as_float(GTK_SPIN_BUTTON(ValeurhumMax1));
max2=gtk_spin_button_get_value_as_float(GTK_SPIN_BUTTON(ValeurhumMax2));
FILE *f; 
f= fopen ("mouvement.txt","r");
if (f!=NULL) {
while(fscanf (f,"%d %d %d %d %f",&id,&j,&mo ,&a, &val)!=EOF){
		if ((val<max1 && val>min1)||(val<max2 && val>min2)) {
		i =0;
while ((i <n) && (ch[i]!=id ))
i++;
if (i==n) {ch[i]=id ; n++ ;}} }
sprintf (texte,"il y a : %d capteurs de mouvement alarmentes ",n);
output=lookup_widget(objet_graphique,("label46"));
gtk_label_set_text(GTK_LABEL(output),texte);
fclose (f);
return (n);}

}
////////////////////////////////////////////////////////////////////////////////////////////

void
on_button11_clicked                       (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{ GtkWidget *fenetre_principale, *fenetre_ajout_supp;
fenetre_ajout_supp=lookup_widget(objet_graphique,"window5");
fenetre_principale=lookup_widget(objet_graphique,"window1");

gtk_widget_destroy(fenetre_ajout_supp);
fenetre_principale=create_window1();
gtk_widget_show(fenetre_principale);


}
///////////////////////////////////////////////////////////////////////////////////////////

void
on_checkbutton_conf_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
*r=1;
else
*r=0;
}
/////////////////////////////////////////////////////////////////////////////////////////
void
on_button12_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget  *fenetre_aff;
fenetre_aff=create_window3();
gtk_widget_show(fenetre_aff);

afficher_capteur(fenetre_aff);

fenetre_aff=lookup_widget(objet_graphique,"window3");

gtk_widget_destroy(fenetre_aff);

}
//////////////////////////////////////////

//Nut_Elyes
void
on_ebrbuttonconnect_clicked            (GtkWidget       *button,
                                        gpointer         user_data)
{
char msg [60];
GtkWidget *username,*password,*ebrwindowen;
GtkWidget *ebrwindowauthen;
char user[20];
char pasw[20];
char user1[20];
char pasw1[20]; int a=0;
username = lookup_widget (GTK_WIDGET(button),"ebrentrylogin");
password = lookup_widget (GTK_WIDGET(button),"ebrentrymdp");
ebrwindowauthen=lookup_widget(GTK_WIDGET(button),"ebrwindowauthen");
strcpy(user,gtk_entry_get_text(GTK_ENTRY(username)));
strcpy(pasw,gtk_entry_get_text(GTK_ENTRY(password)));
FILE *f;
f=fopen("utilisateur.txt","r");
while(fscanf(f,"%s %s \n",user1,pasw1)!=EOF){if (strcmp(user,user1)==0 && strcmp(pasw,pasw1)==0){ a=1;} }

if( a==1){
ebrwindowen=create_ebrwindowen();
gtk_widget_show (ebrwindowen); 
gtk_widget_destroy(ebrwindowauthen);
a=0;
 }
else {


GtkWidget *sortie;
sortie=lookup_widget(GTK_WIDGET(button),"ebrlabelconnect");
strcpy(msg,"identifiant ou mot de passe incorrect");
gtk_label_set_text(GTK_LABEL(sortie),msg);}
fclose(f);
}


void
on_ebrbuttonaficher_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *ebrwindowaffiche;
GtkWidget *treeview1;

ebrwindowaffiche=lookup_widget(objet,"ebrwindowaffiche");
ebrwindowaffiche=create_ebrwindowaffiche();


gtk_widget_show(ebrwindowaffiche);

treeview1=lookup_widget(ebrwindowaffiche,"ebrtreeview1");
afficher(treeview1);

}


void
on_ebrbuttonajout_clicked              (GtkWidget        *button,
                                        gpointer         user_data)
{
  GtkWidget *ebrwindowajouter;
  ebrwindowajouter = create_ebrwindowajouter ();
  gtk_widget_show (ebrwindowajouter);
}


void
on_ebrbuttonchercher_clicked           (GtkWidget        *button,
                                        gpointer         user_data)
{  GtkWidget *ebrwindowchercher;
  ebrwindowchercher = create_ebrwindowchercher ();
  gtk_widget_show (ebrwindowchercher);
}


void
on_ebrbuttonmodifier_clicked           (GtkWidget        *button,
                                        gpointer         user_data)
{ GtkWidget *ebrwindowmodifier;
  ebrwindowmodifier = create_ebrwindowmodifier ();
  gtk_widget_show (ebrwindowmodifier);

}

////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_ebrbuttonmeilleur_clicked           (GtkWidget       *button,
                                        gpointer         user_data)
{

FILE* f;
FILE* fm;
int a,b,na,nb;
float c,nc=1000.00;
  int l;
    char nom[25];
    char type[20];
    char entree[30];
    char suite[30];
    char dessert[30];
    char str[25];
    char date[10];
    char id[10];
char text[15];
char msg[100]="le meilleur menu est ";
GtkWidget *sortie;
sortie=lookup_widget(GTK_WIDGET(button),"ebrlabelme");
// GtkWidget *ebrmeilleur;
f=fopen("dechets.txt","r");
while(fscanf(f,"%d %d %f\n",&a,&b,&c)!=EOF){

  if (nc>c){nc=c;
  nb=b;
  na=a;                 }
}
sprintf(text,"%d",na);
fm=fopen("menu.txt","r");

while(fscanf(fm,"%s %s %s %s %s %s %s\n",id,nom,type,entree,suite,dessert,date)!=EOF){
   



if (strcmp(type,"petit_dej")==0){l=1;}
else if (strcmp(type,"repas")==0){l=2;}
else if (strcmp(type,"dinner")==0){l=3;}

if ((strcmp(date,text)==0) && (nb==l)){ 

strcat(msg,nom);
 gtk_label_set_text(GTK_LABEL(sortie),msg);}
}
fclose(fm);
fclose(f);
}

//////////////////////////////////////////////////////////////////////////////
void
on_ebrbuttonsupprimer_clicked          (GtkWidget        *button,
                                        gpointer         user_data)
{GtkWidget *ebrwindowsupp;
  ebrwindowsupp = create_ebrwindowsupp ();
  gtk_widget_show (ebrwindowsupp);

}
////////////////////////////////////////////////////////////////////////////////////////////////

void
on_ebrtreeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

GtkTreeIter iter;
gchar* id;
gchar* nom;
gchar* type;
gchar* entree;
gchar* suite;
gchar* dessert;
gchar* date;

GtkTreeModel *model = gtk_tree_view_get_model(treeview);
if (gtk_tree_model_get_iter(model,&iter,path))
{
gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&id,1,&nom,2,&type,3,&entree,4,&suite,5,&dessert,6,&date,-1);

strcpy(ident1,id);
}
}


void
on_ebrbuttonajoutermenu_clicked        (GtkWidget       *objet,
                                        gpointer         user_data)
{
menu m;
GtkWidget *input1,*input2,*spin,*input4,*input5,*input6,*input7;
GtkWidget *ebrwindowajouter;
char typea[20],date1[10];
int a;

ebrwindowajouter=lookup_widget(objet,"ebrwindowajouter");

input1=lookup_widget(objet,"ebrentryaid");
input2=lookup_widget(objet,"ebrentryanom");
if (choix==1){strcpy(typea,"petit_dej");}
if (choix==2){strcpy(typea,"repas");}
if (choix==3){strcpy(typea,"dinner");}


input4=lookup_widget(objet,"ebrentryaentree");
input5=lookup_widget(objet,"ebrentryasuite");
input6=lookup_widget(objet,"ebrentryadessert");

//input7=lookup_widget(objet,"entry2");

spin = lookup_widget(objet,"ebrspinbutton1");
a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin));
sprintf(date1,"%d",a);



strcpy(m.id,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(m.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(m.type,typea);
strcpy(m.entree,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(m.suite,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(m.dessert,gtk_entry_get_text(GTK_ENTRY(input6)));
strcpy(m.date,date1);
ajouter(m);
choix=0;

}


void
on_ebrbuttonsupp_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
char a[10];
GtkWidget *input1;
GtkWidget *ebrwindowsupp;

ebrwindowsupp=lookup_widget(objet,"ebrwindowsupp");
input1=lookup_widget(objet,"ebrentrysupp");
strcpy(a,gtk_entry_get_text(GTK_ENTRY(input1)));
supprimer(a);

}


///////////////////////////////////////////////////////////////////////////////////////////////////
void
on_ebrbuttoncherche2_clicked           (GtkWidget       *button,
                                        gpointer         user_data)
{
   GtkWidget *input, *sortie;
   char text[10];
   char msg[100];
input = lookup_widget(button,"ebrentrycherche");
sortie=lookup_widget(button,"ebrlabelmescher");
strcpy(text,gtk_entry_get_text(GTK_ENTRY(input)));
if (chercher(text)==1) {strcpy(msg,"le menu existe");}
else {strcpy(msg,"le menu n'existe pas");}

gtk_label_set_text(GTK_LABEL(sortie),msg);

}

//////////////////////////////////////////////////////////////////////////////////////////
void
on_ebrbuttonyes_clicked                (GtkWidget       *button,
                                        gpointer         user_data)
{
FILE* f;
    char id1[10];
    char id[10];
    char date[10];
    char nom[25];
    char type[20];
    char entree[30];
    char suite[30];
    char dessert[30];
    GtkWidget *input, *input1; 
    int a;
GtkWidget *combobox, *spin;
input1 = lookup_widget(GTK_WIDGET(button),"ebrcomboboxentrymtype");
input = lookup_widget(GTK_WIDGET(button),"ebrentrymid");
spin = lookup_widget(GTK_WIDGET(button),"ebrspinbuttonmdate");
strcpy(id1,gtk_entry_get_text(GTK_ENTRY(input)));
f=fopen("menu.txt","r");
while(fscanf(f,"%s %s %s %s %s %s %s\n",id,nom,type,entree,suite,dessert,date)!=EOF){
if (strcmp(id,id1)==0){
gtk_entry_set_text(GTK_ENTRY(lookup_widget(GTK_WIDGET(button),"ebrentrymnom")),nom);            
gtk_entry_set_text(GTK_ENTRY(lookup_widget(GTK_WIDGET(button),"ebrentrymentree")),entree);
gtk_entry_set_text(GTK_ENTRY(lookup_widget(GTK_WIDGET(button),"ebrentrymsuite")),suite);
gtk_entry_set_text(GTK_ENTRY(lookup_widget(GTK_WIDGET(button),"ebrentrymdessert")),dessert);
if(strcmp(type,"repas")==0) {a=1;}
else if (strcmp(type,"dinner")==0){a=2;}
else {a=0;}
gtk_combo_box_set_active(GTK_COMBO_BOX(input1),a);
gtk_spin_button_set_value(spin,atoi(date));

}
}

fclose(f);


}
////////////////////////////////////////////////////////////////////////////////////

void
on_ebrbuttonenregistrer_clicked        (GtkWidget       *button,
                                        gpointer         user_data)
{
FILE* ft;
FILE* f;
    char id[10];
    char date[10];
    char nom[25];
    char type[20];
    char entree[30];
    char suite[30];
    char dessert[30];
    char id1[10];
    char date1[10];
    char nom1[25];
    char type1[20];
    char entree1[30];
    char suite1[30];
    char dessert1[30];
   int a;
GtkWidget *combobox1, *spin;
GtkWidget *input2, *input1, *input3, *input4, *input5;
spin = lookup_widget(GTK_WIDGET(button),"ebrspinbuttonmdate");
combobox1 = lookup_widget(button,"ebrcomboboxentrymtype");
input1 = lookup_widget(GTK_WIDGET(button),"ebrentrymid");
input2 = lookup_widget(GTK_WIDGET(button),"ebrentrymnom");
input3 = lookup_widget(GTK_WIDGET(button),"ebrentrymentree");
input4 = lookup_widget(GTK_WIDGET(button),"ebrentrymsuite");
input5 = lookup_widget(GTK_WIDGET(button),"ebrentrymdessert");
//
a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin));
sprintf(date1,"%d",a);

strcpy(type1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1))) ;

strcpy(id1,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(nom1,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(entree1,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(suite1,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(dessert1,gtk_entry_get_text(GTK_ENTRY(input5)));




f=fopen("menu.txt","r");
ft=fopen("tmp.txt","ab+");
while(fscanf(f,"%s %s %s %s %s %s %s\n",id,nom,type,entree,suite,dessert,date)!=EOF){



if (strcmp(id,id1)==0) {fprintf(ft,"%s %s %s %s %s %s %s\n",id1,nom1,type1,entree1,suite1,dessert1,date1);}

else {fprintf(ft,"%s %s %s %s %s %s %s\n",id,nom,type,entree,suite,dessert,date);}
}

fclose(f);
fclose(ft);
remove("menu.txt");
rename("tmp.txt","menu.txt");
}


void
on_ebrbuttonajout1_clicked             (GtkWidget       *button,
                                        gpointer         user_data)
{ GtkWidget *ebrwindowajouter;

 ebrwindowajouter = create_ebrwindowajouter ();
  gtk_widget_show (ebrwindowajouter);

}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void
on_ebrbuttonmodifier1_clicked          (GtkWidget       *button,
                                        gpointer         user_data)
{

GtkWidget *ebrwindowmodifier;



 ebrwindowmodifier = create_ebrwindowmodifier ();
  
 gtk_widget_show (ebrwindowmodifier);

}


gboolean
on_ebrwindowmodifier_focus_in_event    (GtkWidget       *button,
                                        GdkEventFocus   *event,
                                        gpointer         user_data)
{


FILE* f;
    
    char id[10];
    char date[10];
    char nom[25];
    char type[20];
    char entree[30];
    char suite[30];
    char dessert[30];
    GtkWidget *input, *input1; 
    int a;


GtkWidget *combobox, *spin;
input1 = lookup_widget(GTK_WIDGET(button),"ebrcomboboxentrymtype");
input = lookup_widget(GTK_WIDGET(button),"ebrentrymid");
spin = lookup_widget(GTK_WIDGET(button),"ebrspinbuttonmdate");
f=fopen("menu.txt","r");
while(fscanf(f,"%s %s %s %s %s %s %s\n",id,nom,type,entree,suite,dessert,date)!=EOF){
if (strcmp(id,ident1)==0){
gtk_entry_set_text(GTK_ENTRY(lookup_widget(GTK_WIDGET(button),"ebrentrymid")),ident1);
gtk_entry_set_text(GTK_ENTRY(lookup_widget(GTK_WIDGET(button),"ebrentrymnom")),nom);            
gtk_entry_set_text(GTK_ENTRY(lookup_widget(GTK_WIDGET(button),"ebrentrymentree")),entree);
gtk_entry_set_text(GTK_ENTRY(lookup_widget(GTK_WIDGET(button),"ebrentrymsuite")),suite);
gtk_entry_set_text(GTK_ENTRY(lookup_widget(GTK_WIDGET(button),"ebrentrymdessert")),dessert);
if(strcmp(type,"repas")==0) {a=1;}
else if (strcmp(type,"dinner")==0){a=2;}
else {a=0;}
gtk_combo_box_set_active(GTK_COMBO_BOX(input1),a);
gtk_spin_button_set_value(spin,atoi(date));


}
}

fclose(f);

  return FALSE;
}

//////////////////////////////////////////////////////////////////////////////////////
void
on_ebrbuttondelete_clicked             (GtkWidget       *button,
                                        gpointer         user_data)
{ 
GtkWidget *ebrwindowconfsupp;
ebrwindowconfsupp = create_ebrwindowconfsupp ();
  gtk_widget_show (ebrwindowconfsupp);

}


gboolean
on_ebrwindowconfsupp_focus_in_event    (GtkWidget       *widget,
                                        GdkEventFocus   *event,
                                        gpointer         user_data)
{

  return FALSE;
}
//////////////////////////////////////////////////////////////////////////////////////

void
on_ebrbuttonsupp3_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *sortie;

sortie=lookup_widget(objet,"ebrlabelmsg");
char a[10];
char msg[30]="cocher pour conifrmer!";
if (sup==1)
{strcpy(a,ident1);
supprimer(a);
sup=0;}
else
gtk_label_set_text(GTK_LABEL(sortie),msg);


}

//////////////////////////////////////////////////////////////////////////////////////
void
on_ebrchecksupp_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton)){sup=1;}
}


//////////////////////////////////////////////////////////////////////////////////////
void
on_ebrradiop_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
choix=1;
}

//////////////////////////////////////////////////////////////////////////////////////
void
on_ebrradior_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
choix=2;
}

//////////////////////////////////////////////////////////////////////////////////////
void
on_ebrradiod_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
choix=3;
}
//////////////////////////////////////////////////////////////////////////////////////

void
on_ebrbuttonretour_clicked             (GtkWidget      *objet,
                                        gpointer         user_data)
{
GtkWidget *ebrwindowaffiche, *ebrwindowen;

ebrwindowen=lookup_widget(objet,"ebrwindowen");
ebrwindowaffiche=lookup_widget(objet,"ebrwindowaffiche");
gtk_widget_destroy(ebrwindowen);
gtk_widget_destroy(ebrwindowaffiche);


}


void
on_ebrbuttonrefresh_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *ebrwindowaffiche, *w1, *treeview1;

w1=lookup_widget(objet,"ebrwindowaffiche");

//ebrwindowaffiche=lookup_widget(objet,"ebrwindowaffiche");


ebrwindowaffiche=create_ebrwindowaffiche();
gtk_widget_show(ebrwindowaffiche);
gtk_widget_hide(w1);

treeview1=lookup_widget(ebrwindowaffiche,"ebrtreeview1");

vider(treeview1);
afficher(treeview1);

}



//////////////////////////////////////////////////////////////////////////////////////

void
on_SMARTbutton13_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *ebrwindowauthen, *smartwindow;

ebrwindowauthen=create_ebrwindowauthen();
gtk_widget_show (ebrwindowauthen); 
gtk_widget_destroy(smartwindow);
}

//////////////////////////////////////////////////////////////////////////////////////
void
on_smartbutton15_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *auth_et, *smartwindow;
auth_et=create_auth_et();
gtk_widget_show (auth_et); 
gtk_widget_destroy(smartwindow);

}
//////////////////////////////////////////////////////////////////////////////////////

void
on_smartbutton14_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *FDauthent, *smartwindow;
FDauthent=create_FDauthent();
gtk_widget_show (FDauthent); 
gtk_widget_destroy(smartwindow);
}

//////////////////////////////////////////////////////////////////////////////////////
void
on_smartbutton16_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1, *smartwindow;
window1=create_window1();
gtk_widget_show (window1); 
gtk_widget_destroy(smartwindow);
}
//////////////////////////////////////////////////////////////////////////////////////

void
on_FDradiobutton9_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{k=1;}
}


////////////////////////////////////////////////////////////////////////////////////////////////////////

void
on_buttonactualiser_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview1ZA;
windowreclamationZA=lookup_widget(button,"windowreclamationZA");
treeview1ZA=lookup_widget(windowreclamationZA,"treeview1ZA");
affichage(treeview1ZA);
}
void
on_buttonsupprimer_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
RECLAMATION r;
	    GtkWidget *treeview1ZA;
	    windowreclamationZA=lookup_widget(button,"windowreclamationZA");
	    treeview1ZA=lookup_widget(windowreclamationZA,"treeview1ZA");
	
	    suppression(id,r);
            affichage(treeview1ZA);
}

void
on_buttonajouter_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
		gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowreclamationZA,"notebook1")));
}
void
on_buttonmodifier_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
		gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowreclamationZA,"notebook1")));
                gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowreclamationZA,"notebook1")));
}
void
on_buttonboard_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
		gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowreclamationZA,"notebook1")));
                gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowreclamationZA,"notebook1")));
		gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowreclamationZA,"notebook1")));
}


void
on_buttonajout_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
RECLAMATION r;char Type[30];
GtkWidget *comboboxajout;
GtkWidget *entryid;
GtkWidget *entryprob;

GtkWidget *spinbuttonjj;
GtkWidget *spinbuttonmm;
GtkWidget *spinbuttonaa;

GtkWidget *spinbuttonjour;
GtkWidget *spinbuttonmois;
GtkWidget *spinbuttonanne;
 
if (a==1){	
spinbuttonjour=lookup_widget(button, "spinbuttonjour");
spinbuttonmois=lookup_widget(button, "spinbuttonmois");
spinbuttonanne=lookup_widget(button, "spinbuttonanne");
spinbuttonjj=lookup_widget(button, "spinbuttonjj");
spinbuttonmm=lookup_widget(button, "spinbuttonmm");
spinbuttonaa=lookup_widget(button, "spinbuttonaa");

comboboxajout=lookup_widget(button, "comboboxajout");
entryid=lookup_widget(button,"entryid");
entryprob=lookup_widget(button,"entryprob");

strcpy(r.identifiant,gtk_entry_get_text(GTK_ENTRY(entryid)));
strcpy(r.problem,gtk_entry_get_text(GTK_ENTRY(entryprob)));

r.dater.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonjour));
r.dater.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonmois));
r.dater.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonanne));
r.datea.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonjj));
r.datea.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonmm));
r.datea.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonaa));
strcpy(Type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxajout)));
strcpy(r.type,Type);

ajout(r);

}}


void
on_buttonmodif_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
RECLAMATION r;char Type[30];
GtkWidget *comboboxmodif;
GtkWidget *entrymodifid;
GtkWidget *entrymodifprob;
GtkWidget *spinbuttonmodifjj;
GtkWidget *spinbuttonmodifmm;
GtkWidget *spinbuttonmodifaa;

GtkWidget *spinbuttonmodifjour;
GtkWidget *spinbuttonmodifmois;
GtkWidget *spinbuttonmodifanne;

    
if (m==1){	
spinbuttonmodifjour=lookup_widget(button, "spinbuttonmodifjour");
spinbuttonmodifmois=lookup_widget(button, "spinbuttonmodifmois");
spinbuttonmodifanne=lookup_widget(button, "spinbuttonmodifanne");
spinbuttonmodifjj=lookup_widget(button, "spinbuttonmodifjj");
spinbuttonmodifmm=lookup_widget(button, "spinbuttonmodifmm");
spinbuttonmodifaa=lookup_widget(button, "spinbuttonmodifaa");
comboboxmodif=lookup_widget(button, "comboboxmodif");
entrymodifid=lookup_widget(button,"entrymodifid");
entrymodifprob=lookup_widget(button,"entrymodifprob");


strcpy(r.identifiant,gtk_entry_get_text(GTK_ENTRY(entrymodifid)));
strcpy(r.problem,gtk_entry_get_text(GTK_ENTRY(entrymodifprob)));
r.dater.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonmodifjour));
r.dater.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonmodifmois));
r.dater.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonmodifanne));
r.datea.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonmodifjj));
r.datea.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonmodifmm));
r.datea.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonmodifaa));
strcpy(Type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxmodif)));
strcpy(r.type,Type);


modification(id,r);}

}


void
on_buttonafficher_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
char chr[30];char chh[30];
int k,h;
RECLAMATION r;
GtkWidget *labelrest;
GtkWidget *labelheb;
GtkWidget *labelstat;
k=nombrer(r);
h=nombreh(r);
labelrest=lookup_widget(button,"labelrest");
labelheb=lookup_widget(button,"labelheb");
labelstat=lookup_widget(button,"labelstat");
sprintf(chr,"%d",k);
sprintf(chh,"%d",h);
gtk_label_set_text(labelrest,chr);
gtk_label_set_text(labelheb,chh);
if (k>h)
{gtk_label_set_text(labelstat,"service Restauration");}
else 
{gtk_label_set_text(labelstat,"service Hébergement");}

}


void
on_buttonrecherche_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{


RECLAMATION r;
GtkWidget *entryrech;
GtkWidget *treeview1ZA;
FILE*f;
FILE*f2;


windowreclamationZA=lookup_widget(button,"windowreclamationZA");
entryrech=lookup_widget(button,"entryrech");
strcpy(idrech,gtk_entry_get_text(GTK_ENTRY(entryrech)));
f=fopen("reclamation.bin","rb");

 if(f!=NULL)
 {
  while(fread(&r,sizeof(RECLAMATION),1,f))
     {
       f2=fopen("recherche.bin","ab+");
       if  (f2!=NULL)
   {  
     
     if (strcmp(r.identifiant,idrech)==0)
     { 
     fwrite(&r,sizeof(RECLAMATION),1,f2);
     }
   
     treeview1ZA=lookup_widget(windowreclamationZA,"treeview1ZA");
     recherche(treeview1ZA);
    
        fclose(f2);
    }

 }
 fclose(f);
}
remove("recherche.bin");
}
void
on_checkbuttonvm_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton)){
m=1;}
}


void
on_checkbuttonva_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton)){
a=1;}
}


void
on_treeview1ZA_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar* identifiant;
	GtkTreeModel *Model = gtk_tree_view_get_model(treeview);

		if (gtk_tree_model_get_iter(Model, &iter, path)){
				gtk_tree_model_get(GTK_LIST_STORE(Model),&iter,1,&identifiant, -1);
				strcpy(id,identifiant);}}


void
on_smartbutton18_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowreclamationZA, *smartwindow;
windowreclamationZA=create_windowreclamationZA();
gtk_widget_show (windowreclamationZA); 
gtk_widget_destroy(smartwindow);
}
///////////////////////////////////////////////////////
void
on_CG_auth_connecter_btn_clicked       (GtkWidget       *objet,
                                        gpointer         user_data)
{

}


void
on_CG_auth_insc_btn_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{

}


void
on_CG_aff_users_btn_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{GtkWidget *windowCG_show, *window_destroy;
GtkWidget *treeview1;
window_destroy=lookup_widget(objet,"CG_welcome");
gtk_widget_destroy(window_destroy);
windowCG_show=create_CG_aff();
gtk_widget_show (windowCG_show);

treeview1=lookup_widget(windowCG_show,"CG_treeview");
afficherC(treeview1);

}


void
on_CG_quitter_btn_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{GtkWidget *windowCG_auth, *window_destroy;
window_destroy=lookup_widget(objet,"CG_welcome");
gtk_widget_destroy(window_destroy);
windowCG_auth=create_CG_auth();
gtk_widget_show (windowCG_auth);

}


void
on_CG_treeview_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{GtkTreeIter iter;
gchar *nom;
gchar *prenom;
gchar *sexe;
gint *age;
gint *num;
gchar *email;
gchar *cin;
gchar *poste;
user p;
GtkTreeModel *model =gtk_tree_view_get_model(treeview);
if(gtk_tree_model_get_iter(model,&iter,path))
{
gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&nom,1,&prenom,2,&cin,3,&age,4,&sexe,5,&num,6,&email,7,&poste,-1);
strcpy(p.nom,nom);
strcpy(p.prenom,prenom);
strcpy(p.cin,cin);
strcpy(p.sexe,sexe);
strcpy(p.email,email);
strcpy(p.poste,poste);
p.age=age;
p.num=num;
supp(p);
afficherC(treeview);
}

}


void
on_CG_aff_rech_btn_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{GtkWidget *p1;
GtkWidget *entry;
GtkWidget *labelcin;
GtkWidget *nbResultat;
GtkWidget *message;
char cin[30];
char chnb[30];
int b=0,nb;
entry=lookup_widget(objet,"CG_aff_rech_entry");
//labelid=lookup_widget(gestion,"label47");
p1=lookup_widget(objet,"CG_treeview");
strcpy(cin,gtk_entry_get_text(GTK_ENTRY(entry)));
nb=chercher_user(p1,"user.txt",cin);

}


void
on_CG_aff_modif_btn_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *windowCG_modif, *window_destroy;
window_destroy=lookup_widget(objet,"CG_aff");
gtk_widget_destroy(window_destroy);
windowCG_modif=create_CG_modifier();
gtk_widget_show (windowCG_modif);
}


void
on_CG_add_homme_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
sexe=1;

}


void
on_CG_add_femme_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
sexe=2;

}


void
on_CG_add_retour_btn_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{GtkWidget *windowCG_aff, *window_destroy;
window_destroy=lookup_widget(objet,"CG_add");
gtk_widget_destroy(window_destroy);
windowCG_aff=create_CG_aff();
gtk_widget_show (windowCG_aff);

}


void
on_CG_add_add_btn_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{user c;
int a;
GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*input7,*input8,*input9;
GtkWidget *fenetre_ajout;
GtkWidget *fail,*succ;
fail=lookup_widget(objet,"label_fail");
succ=lookup_widget(objet,"label_succ");



fenetre_ajout=lookup_widget(objet,"CG_add");
input1=lookup_widget(objet,"CG_add_name");
input2=lookup_widget(objet,"CG_add_prename");
input3=lookup_widget(objet,"CG_add_cin");
input4=lookup_widget(objet,"CG_add_num");
input5=lookup_widget(objet,"CG_add_email");

input6=lookup_widget(objet,"CG_add_combo_poste");
input7=lookup_widget(objet,"CG_add_spin_age");
input8=lookup_widget(objet,"CG_add_homme");
input9=lookup_widget(objet,"CG_add_femme");

if(sexe==1)
{
//gtk_toggle_button_set_active(GTK_RADIO_BUTTON(input8),TRUE);
strcpy(c.sexe,"Homme");
}
else
{
//gtk_toggle_button_set_active(GTK_RADIO_BUTTON(input9),TRUE);
strcpy(c.sexe,"Femme");
}

strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(c.prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(c.cin,gtk_entry_get_text(GTK_ENTRY(input3)));
c.num=atoi(gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(c.email,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(c.poste,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input6)));

a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input7));
c.age=a;
if(x==1)
{
if(strcmp(c.nom,"")!=0&&strcmp(c.prenom,"")!=0&&strcmp(c.cin,"")!=0&&strcmp(c.sexe,"")!=0&& (c.age>=18) && (c.num!=0) && strcmp(c.email,"")!=0&&strcmp(c.poste,"")!=0)
{gtk_widget_show(succ);
gtk_widget_hide(fail);
add_user(c);
}
else {
gtk_widget_show(fail);
gtk_widget_hide(succ);}
}

}


void
on_CG_confirmer_check_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{if(gtk_toggle_button_get_active(togglebutton))
x=1;

}


void
on_CG_modif_femme_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
sexem=2;

}


void
on_CG_modif_annuler_btn_clicked        (GtkWidget       *objet,
                                        gpointer         user_data)
{GtkWidget *windowCG_aff, *window_destroy;
window_destroy=lookup_widget(objet,"CG_modifier");
gtk_widget_destroy(window_destroy);
windowCG_aff=create_CG_aff();
gtk_widget_show (windowCG_aff);

}

void
on_CG_modif_modif_btn_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{GtkWidget *cin,*nom,*prenom,*age,*sexe1,*sexe2,*poste,*email,*numero,*rech;
GtkWidget *fail,*succ;
user p;
char reche[200];
fail=lookup_widget(objet,"label_mod_fail");
succ=lookup_widget(objet,"label_mod_succ");
rech=lookup_widget(objet,"CG_modif_chercher");
strcpy(reche,gtk_entry_get_text(GTK_ENTRY(rech)));
cin=lookup_widget(objet,"CG_modif_cin");
nom=lookup_widget(objet,"CG_modif_nom");
prenom=lookup_widget(objet,"CG_modif_prenom");
strcpy(p.cin,gtk_entry_get_text(GTK_ENTRY(cin)));
strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(p.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));

age=lookup_widget(objet,"CG_modif_spin_age");
p.age=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(age));

sexe1=lookup_widget(objet,"CG_modif_homme");
sexe2=lookup_widget(objet,"CG_modif_femme");
if(sexem==1)
{
strcpy(p.sexe,"Homme");
}
else
{
strcpy(p.sexe,"Femme");
}
poste=lookup_widget(objet,"CG_modif_combo_poste");
strcpy(p.poste,gtk_combo_box_get_active_text(GTK_COMBO_BOX(poste)));

email=lookup_widget(objet,"CG_modif_email");
strcpy(p.email,gtk_entry_get_text(GTK_ENTRY(email)));

numero=lookup_widget(objet,"CG_modif_num");
p.num=atoi(gtk_entry_get_text(GTK_ENTRY(numero)));


if(strcmp(p.nom,"")!=0&&strcmp(p.prenom,"")!=0&&strcmp(p.cin,"")!=0&&strcmp(p.sexe,"")!=0&& (p.age>=18) && (p.num!=0) && strcmp(p.email,"")!=0&&strcmp(p.poste,"")!=0)
{gtk_widget_show(succ);
gtk_widget_hide(fail);
supp_cin(reche);
add_user(p);
}
else {
gtk_widget_show(fail);
gtk_widget_hide(succ);}


/*gtk_widget_show (message);
gtk_label_set_text(GTK_LABEL(message),"la modification est validée");*/


}


void
on_CG_inscrit_admin_incrit_btn_clicked (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_CG_inscrit_admin_retour_btn_clicked (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_CG_etage_row_activated              (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_CG_refresh_etage_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{GtkWidget *fenetre_afficher,*w1;
GtkWidget *treeview1;
w1=lookup_widget(objet,"CG_liste");
fenetre_afficher=create_CG_liste();
gtk_widget_show(fenetre_afficher);
gtk_widget_hide(w1);
treeview1=lookup_widget(fenetre_afficher,"CG_treeetage");
afficher_etage(treeview1);

}


void
on_CG_modif_homme_activate             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
sexem=1;

}


void
on_CG_aff_add_btn_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *windowCG_add, *window_destroy;
GtkWidget *fail,*succ;

window_destroy=lookup_widget(objet,"CG_aff");
gtk_widget_destroy(window_destroy);
windowCG_add=create_CG_add();
gtk_widget_show (windowCG_add);
fail=lookup_widget(objet,"label_fail");
succ=lookup_widget(objet,"label_succ");
gtk_widget_hide(fail);
gtk_widget_hide(succ);
}


void
on_CG_aff_supp_btn_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{GtkTreeModel     *model;
        GtkTreeSelection *selection;
        GtkTreeIter iter;
        GtkWidget* p;
        GtkWidget *label;
        gchar *cin;
        
        p=lookup_widget(objet,"CG_treeview");
	
	selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))//test sur la ligne selectionnée
        {  gtk_tree_model_get (model,&iter,2,&cin,-1);
           gtk_list_store_remove(GTK_LIST_STORE(model),&iter);//supprimer la ligne du treeView

           supp_cin(cin);

	afficherC(p);
}

}


void
on_CG_aff_retour_btn_clicked           (GtkWidget      *objet,
                                        gpointer         user_data)
{GtkWidget *windowCG_welcome, *window_destroy;
window_destroy=lookup_widget(objet,"CG_aff");
gtk_widget_destroy(window_destroy);
windowCG_welcome=create_CG_welcome();
gtk_widget_show (windowCG_welcome);

}


void
on_CG_modif_chercher_btn_clicked       (GtkWidget      *objet,
                                        gpointer         user_data)
{
GtkWidget *cin,*nom,*prenom,*age,*genre,*email,*numero,*rech,*poste,*se1,*se2,*message;
user c;
user p;
char nmch[30];
char reche[200];
int i=0;
char matrice[6][30]={"Administrateur","Technicien","Nutritionniste","Agent_de_foyer","Agent_de_restaurant","Etudiant"};
cin=lookup_widget(objet,"CG_modif_cin");
nom=lookup_widget(objet,"CG_modif_nom");
prenom=lookup_widget(objet,"CG_modif_prenom");
email=lookup_widget(objet,"CG_modif_email");
numero=lookup_widget(objet,"CG_modif_num");

age=lookup_widget(objet,"CG_modif_spin_age");

se1=lookup_widget(objet,"CG_modif_homme");
se2=lookup_widget(objet,"CG_modif_femme");

poste=lookup_widget(objet,"CG_modif_combo_poste");

rech=lookup_widget(objet,"CG_modif_chercher");


strcpy(reche,gtk_entry_get_text(GTK_ENTRY(rech)));
//printf("hello world");
FILE *f=NULL;
int v=1;
f=fopen("user.txt","r");
while(fscanf(f,"%s %s %s %s %d %d %s %s \n",c.nom,c.prenom,c.cin,c.sexe,&c.age,&c.num,c.email,c.poste)!=EOF)
        {
	if( strcmp(reche,c.cin)==0){
			gtk_widget_hide (message);
			v=0;
			strcpy(p.cin,c.cin);
			strcpy(p.nom,c.nom);
			strcpy(p.prenom,c.prenom);
			strcpy(p.email,c.email);
			p.num=c.num;
			p.age=c.age;
			strcpy(p.poste,c.poste);
			strcpy(p.sexe,c.sexe);
			
			
			
	}
	else 
		{gtk_widget_show (message);
		gtk_label_set_text(GTK_LABEL(message),"ce cin n'existe pas");
		gtk_entry_set_text (cin,"");
		gtk_entry_set_text (nom,"");
		gtk_entry_set_text (prenom,"");
		gtk_entry_set_text (numero,"");
		gtk_entry_set_text (age,"");
		gtk_entry_set_text (sexe,"");
		gtk_entry_set_text (email,"");
		gtk_entry_set_text (poste,"");

}
}
if(v==0)
{
	gtk_entry_set_text (cin,p.cin);
	gtk_entry_set_text (nom,p.nom);
	gtk_entry_set_text (prenom,p.prenom);
	if(strcmp(p.sexe,"Homme")==0)
	{
	gtk_toggle_button_set_active(GTK_RADIO_BUTTON (se1),TRUE);
	}
	else if(strcmp(p.sexe,"Femme")==0) {
	gtk_toggle_button_set_active(GTK_RADIO_BUTTON (se2),TRUE);
	}
	i=0;
	while(i<6 && strcmp(matrice[i],p.poste)!=0)
	{
	i++;}
	gtk_combo_box_set_active(GTK_COMBO_BOX(poste),i);
	
	gtk_spin_button_set_value(age,p.age);
	sprintf(nmch,"%d",p.num);
	gtk_entry_set_text(numero,nmch);
	gtk_entry_set_text (email,p.email);
	gtk_widget_hide (message);
}
}


void
on_CG_accualiser_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{GtkWidget *fenetre_afficher,*w1;
GtkWidget *treeview1;

w1=lookup_widget(objet,"CG_aff");
fenetre_afficher=create_CG_aff();
gtk_widget_show(fenetre_afficher);
gtk_widget_hide(w1);
treeview1=lookup_widget(fenetre_afficher,"CG_treeview");
afficherC(treeview1);

}


void
on_smartbutton50_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *CG_welcome, *smartwindow;

CG_welcome=create_CG_welcome();
gtk_widget_show (CG_welcome); 
gtk_widget_destroy(smartwindow);
}

