#include <gtk/gtk.h>



void
on_FDins_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_FDlogin_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_FDaj_clicked                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_FDmod_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_FDsup_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_FDajo_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_FDcherch_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_FDaffich_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_FDaf_prd_row_activated              (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_FDo_toggled                         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_FDn_toggled                         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_FDtrouver_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_FDout_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_FDret_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_FDouut_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_FDbutton6_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_FDbutton5_clicked                   (GtkButton       *button,
                                        gpointer         user_data);



void
on_FDcheckbutton1_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_FDbutton4_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_FDbutton1_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_FDbutton2_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_FDbutton3_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_FDradiobutton1_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_FDradiobutton2_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_FDbutton7_clicked                   (GtkButton       *button,
                                        gpointer         user_data);


void
on_FDbutton66_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_FDbutton55_clicked                  (GtkButton       *button,
                                        gpointer         user_data);



void
on_FDsuppp_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_FDactiver_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

/*void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);*/

void
on_FDconfirmer_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_FDtrrup_row_activated               (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);
void
on_treeview1_user_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_go_ajouter_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_go_supprimer_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_go_modifier_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_actualiser_user_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_rechercher_user_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_deconn_user_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_et_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_chercher_et_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_ajouter_et_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour_modifier_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifier_et_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour_ajouteret_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour_modifier_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_annuler_supp_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_conf_supp_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_et_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_et_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ZAcheckbutton1_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_auth_et_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_inns_ett_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_insc_et_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_anul_ins_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_stat_etttttt_clicked                (GtkButton       *button,
                                        gpointer         user_data);
/*void
on_gb_auth_insc_btn_clicked            (GtkWidget      *objet,
                                        gpointer         user_data);
void
on_gb_auth_connecter_btn_clicked       (GtkWidget      *objet,
                                        gpointer         user_data);
void
on_gb_quitter_btn_clicked              (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_gb_treeview_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_gb_aff_retour_btn_clicked           (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_gb_aff_modif_btn_clicked             (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_gb_aff_supp_btn_clicked             (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_gb_aff_rech_btn_clicked             (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_gb_aff_add_btn_clicked              (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_gb_add_retour_btn_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_gb_add_add_btn_clicked              (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_gb_modif_annuler_btn_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_gb_modif_modif_btn_clicked          (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_gb_modif_chercher_btn_clicked       (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_gb_aff_users_btn_clicked            (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_gb_inscrit_admin_incrit_btn_clicked (GtkButton       *button,
                                        gpointer         user_data);

void
on_gb_inscrit_admin_retour_btn_clicked (GtkButton       *button,
                                        gpointer         user_data);

void
on_gb_confirmer_check_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_gb_add_homme_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_gb_add_femme_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_gb_accualiser_clicked               (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_gb_modif_homme_activate             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_gb_modif_femme_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_gb_treefumee_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_gb_treemvt_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_gb_refresh_mvt_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);
void
on_gb_refresh_fumee_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);*/
void
on_ajouter1_clicked                   ( GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_modifier1_clicked                   ( GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_supprimer1_clicked                  ( GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_consulter_clicked                   ( GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_ajout_clicked                     (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_modif_clicked                     (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button_affich1_clicked               ( GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button7_ret_clicked               ( GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_supp_clicked                        ( GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button10_affich_clicked              ( GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button9_ret_clicked                 ( GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_recherche_clicked                    ( GtkWidget      *objet_graphique,
                                        gpointer         user_data);


void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void
on_button7_clicked                      (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_treeview2_rech_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button8_actu_clicked                 (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button8_al_clicked                   (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button9_tm_clicked               (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button10_clicked                  (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button11_clicked                     (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_checkbutton_conf_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button12_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);
void
on_ebrbuttonconnect_clicked            (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ebrbuttonaficher_clicked            (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ebrbuttonajout_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ebrbuttonchercher_clicked           (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ebrbuttonmodifier_clicked           (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ebrbuttonmeilleur_clicked           (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ebrbuttonsupprimer_clicked          (GtkWidget       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_ebrbuttonajoutermenu_clicked        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ebrbuttonsupp_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ebrbuttoncherche2_clicked           (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ebrbuttonyes_clicked                (GtkWidget      *button,
                                        gpointer         user_data);

void
on_ebrbuttonenregistrer_clicked        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ebrbuttonajout1_clicked             (GtkWidget       *button,
                                        gpointer         user_data);


void
on_ebrbuttonmodifier1_clicked          (GtkWidget       *button,
                                        gpointer         user_data);

gboolean
on_ebrwindowmodifier_focus_in_event    (GtkWidget       *widget,
                                        GdkEventFocus   *event,
                                        gpointer         user_data);

void
on_ebrbuttondelete_clicked             (GtkWidget       *button,
                                        gpointer         user_data);

gboolean
on_ebrwindowconfsupp_focus_in_event    (GtkWidget       *widget,
                                        GdkEventFocus   *event,
                                        gpointer         user_data);

void
on_ebrbuttonsupp3_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ebrchecksupp_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_ebrradiop_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ebrradior_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ebrradiod_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ebrbuttonretour_clicked             (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ebrbuttonrefresh_clicked            (GtkWidget      *button,
                                        gpointer         user_data);

void
on_ebrtreeview1_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_SMARTbutton13_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_smartbutton15_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_smartbutton14_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_smartbutton16_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_FDradiobutton9_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);



/////////////////////////////////
void
on_buttonactualiser_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonsupprimer_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonajouter_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonmodifier_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonboard_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonajout_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonmodif_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonafficher_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonrecherche_clicked             (GtkButton       *button,
                                        gpointer         user_data);



void
on_checkbuttonvm_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbuttonva_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_treeview1ZA_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_smartbutton18_clicked               (GtkButton       *button,
                                        gpointer         user_data);
void
on_CG_auth_insc_btn_clicked            (GtkWidget      *objet,
                                        gpointer         user_data);
void
on_CG_auth_connecter_btn_clicked       (GtkWidget      *objet,
                                       gpointer         user_data);

void
on_CG_quitter_btn_clicked              (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_CG_treeview_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_CG_aff_retour_btn_clicked           (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_CG_aff_modif_btn_clicked             (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_CG_aff_supp_btn_clicked             (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_CG_aff_rech_btn_clicked             (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_CG_aff_add_btn_clicked              (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_CG_add_retour_btn_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_CG_add_add_btn_clicked              (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_CG_modif_annuler_btn_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_CG_modif_modif_btn_clicked          (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_CG_modif_chercher_btn_clicked       (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_CG_aff_users_btn_clicked            (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_CG_inscrit_admin_incrit_btn_clicked (GtkButton       *button,
                                        gpointer         user_data);

void
on_CG_inscrit_admin_retour_btn_clicked (GtkButton       *button,
                                        gpointer         user_data);

void
on_CG_confirmer_check_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_CG_add_homme_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_CG_add_femme_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_CG_accualiser_clicked               (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_CG_modif_homme_activate             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_CG_modif_femme_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_CG_treeetage_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);
void 
on_CG_etage_row_activated              (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);
void
on_CG_refresh_etage_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_smartbutton50_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_FDradiobutton9_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_et_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_et_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_smartbutton150_clicked              (GtkButton       *button,
                                        gpointer         user_data);
